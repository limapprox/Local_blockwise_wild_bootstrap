# Copyright: Yicong Lin, Mingxuan Song, Bernhard van der Sluis
#
# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

# ==================================================#
# Researchers are free to use the code.
# Please cite the following papers:
# 1. Yicong Lin, Mingxuan Song and Bernhard van der Sluis (2024). Bootstrap inference for linear time-varying coefficient models in locally stationary time series.
# 2. Marina Friedrich and Yicong Lin (2024). Sieve bootstrap inference for linear time-varying coefficient models. Journal of Econometrics.

# Purpose: applying our methods to the empirical case in Section 5, herding effects in Chinese renewable energy market.
######################################################


### Imports

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from statsmodels.tsa.ar_model import ar_select_order
from statsmodels.tsa.ar_model import AutoReg
import math
import warnings

warnings.filterwarnings('ignore')
import scipy
import matplotlib

# In[]
###########################################################
#### Estimation
# kernel function
def K(u):
    return np.where(np.abs(u) <= 1, 0.75 * (1 - u ** 2), 0)


def Sn(k, tau, mX, h, times):
    u = (times[None, :] - tau) / h
    K_u = K(u)

    if mX.ndim == 2:
        return np.sum((mX[:, None, :] * mX[:, :, None]) * np.reshape(((times[None, :] - tau) ** k) * K_u,
                                                                     newshape=(len(times), 1, 1)), axis=0) / (h)
    elif mX.ndim == 1:
        return np.sum((mX[:, None] * mX[:, None]) * np.reshape(((times[None, :] - tau) ** k) * K_u,
                                                               newshape=(len(times), 1)), axis=0) / (h)


def Tn(k, tau, mX, vY, h, times):
    u = (times[None, :] - tau) / h
    K_u = K(u)

    if mX.ndim == 2:
        return np.sum(
            mX[:, :, None] * np.reshape((times[None, :] - tau) ** k * K_u, newshape=(len(times), 1, 1)) * vY.reshape(
                len(times), 1, 1), axis=0) / (h)
    elif mX.ndim == 1:
        return np.sum(
            mX[:, None] * np.reshape((times[None, :] - tau) ** k * K_u, newshape=(len(times), 1)) * vY.reshape(
                len(times), 1), axis=0) / (h)


def get_mS(tau, mX, h, times, n_dim):
    mS = np.zeros(shape=(n_dim, n_dim))
    Sn0 = Sn(0, tau, mX, h, times)
    Sn1 = Sn(1, tau, mX, h, times)
    Sn2 = Sn(2, tau, mX, h, times)
    size = Sn0.shape[0]

    mS[:size, :size] = Sn0
    mS[:size, size:] = Sn1
    mS[size:, :size] = Sn1.T
    mS[size:, size:] = Sn2

    return mS


def get_mT(tau, mX, vY, h, times, n_dim):
    mT = np.zeros(shape=(n_dim, 1))
    Tn0 = Tn(0, tau, mX, vY, h, times)
    Tn1 = Tn(1, tau, mX, vY, h, times)
    size = Tn0.shape[0]

    if n_dim == 2:
        mT[:size, 0] = Tn0
        mT[size:, 0] = Tn1
    else:
        mT[:size, 0] = Tn0[:, 0]
        mT[size:, 0] = Tn1[:, 0]

    return mT

# local linear estimation
def estimator(vY, mX, h, tau, times, n_est):
    betahat = np.zeros(shape=(n_est, len(tau)))
    for i in range(len(tau)):
        mS, mT = get_mS(tau[i], mX, h, times, 2 * n_est), get_mT(tau[i], mX, vY, h, times, 2 * n_est)
        mul = np.linalg.inv(mS) @ mT

        for j in range(n_est):
            betahat[j, i] = mul[j] if j < n_est else 0

    return betahat


# In[]
#### Sieve and sieve wild bootstrap functions
def AR(zhat, T):
    maxp = 10 * np.log10(T)
    arm_selection = ar_select_order(zhat, ic='aic', trend='n', maxlag=int(maxp))

    if arm_selection.ar_lags is None:  ######
        armodel = AutoReg(zhat, trend='n', lags=0).fit()
        max_lag = 0  ## to avoid the nonetype error
        epsilonhat = zhat
        epsilontilde = epsilonhat - np.mean(epsilonhat)
    else:
        armodel = arm_selection.model.fit()
        max_lag = max(arm_selection.ar_lags)
        epsilonhat = armodel.resid
        epsilontilde = epsilonhat - np.mean(epsilonhat)

    return epsilontilde, max_lag, armodel

# sieve bootstrap
def S_BT(epsilontilde, max_lag, zhat, armodel, mX, betatilde, T):
    epsilonstar = np.random.choice(epsilontilde, T - max_lag + 50)
    if max_lag == 0:
        zstar = epsilonstar[50:]
        zstar_array = zstar
    else:
        max_lag = np.arange(1, max_lag + 1)
        zstar_array = get_Zstar_AR(max_lag, armodel, T, epsilonstar)

    if mX.ndim == 1:
        vYstar = (mX * betatilde[0] + zstar_array)
        return vYstar
    elif mX.ndim == 2:
        vYstar = (mX @ betatilde + zstar_array).diagonal()
        return vYstar

# sieve wild bootstrap
def SW_BT(epsilontilde, max_lag, zhat, armodel, mX, betatilde, T):
    epsilonstar = epsilontilde * np.random.normal(0, 1, T - max_lag)
    epsilonstar = np.random.choice(epsilonstar, T - max_lag + 50)
    if max_lag == 0:
        zstar = epsilonstar[50:]
        zstar_array = zstar
    else:
        max_lag = np.arange(1, max_lag + 1)
        zstar_array = get_Zstar_AR(max_lag, armodel, T, epsilonstar)

    if mX.ndim == 1:
        vYstar = (mX * betatilde[0] + zstar_array)
        return vYstar
    elif mX.ndim == 2:
        vYstar = (mX @ betatilde + zstar_array).diagonal()

        return vYstar


def get_Zstar_AR(max_lags, armodel, T, epsilonstar):
    # Initialize the AR process with the known initial values
    zstar = np.zeros(len(max_lags))

    # Add the AR component for each lag value and coefficient
    for i in range(len(max_lags), T):
        ar_component = 0
        for j, lag in enumerate(max_lags):
            lagged_data = zstar[i - lag]
            ar_component += armodel.params[j] * lagged_data

        ar_component += epsilonstar[i + 20 - len(max_lags)]

        zstar = np.append(zstar, ar_component)

    return zstar

# In[]
# LBW bootstrap
def LBW_BT(zhat, mX, betatilde, T):
    '''
    Local blockwise wild bootstrap

    Parameters
    ----------
    zhat : array
        residuals.
    mX : matrix
        regressor matrix.
    betatilde : array
        oversmoothed estimate.
    T : integer
        sample size.

    Returns
    -------
    vYstar : array
        bootstrap sample.

    '''
    h = 0.0975
    l = int(np.floor(4.5 * ((T * h) ** (0.25))))
    number_blocks = T - l + 1
    
    # construct all blocks
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        overlapping_blocks[i] = np.array(zhat[i:i + l]).reshape(l, 1)
    
    # sample blocks
    zstar = np.zeros(shape=(l * int(np.ceil(T / l)), 1))
    for tau in range(0, T, l):
        # get the number of local blocks
        local_number_blocks = np.shape(overlapping_blocks[max(tau - l, 0):tau + l])[0]
        
        # choose randomly the index of the local block to sample
        random_choice = np.random.choice(np.arange(0, local_number_blocks), 1)
        
        # get wild component
        vWild = np.repeat(np.random.normal(0, 1, 1), l)
        
        # get randomly chosen local block
        overlapping_blocks_star = (overlapping_blocks[max(tau - l, 0):tau + l])[random_choice]
        
        # lay out the local block
        zstar[tau:tau + l] = overlapping_blocks_star.reshape(l, 1) * vWild.reshape(l, 1)

    # get first T observations sampled by LBWB
    zstar = zstar[:T]
    
    # construct bootstrap sample
    if mX.ndim == 1:
        # vYstar = np.reshape(mX*betatilde[0],(T,1))+ zstar
        vYstar = (mX * betatilde[0] + zstar).diagonal()
        return vYstar
    elif mX.ndim == 2:
        vYstar = (mX @ betatilde + zstar).diagonal()
        return vYstar

# In[]
#### Simultaneous bands
def get_qtau(alphap, diff, tau):
    qtau = np.zeros(shape=(2, len(tau)))
    for i in range(len(tau)):
        qtau[0, i] = np.quantile(diff[:, i], alphap / 2)

        qtau[1, i] = np.quantile(diff[:, i], (1 - alphap / 2))
    return qtau


def ABS_value(qtau, diff, tau):
    B = 1299
    check = np.sum((qtau[0][:, None] < diff[:, :, None]) & (diff[:, :, None] < qtau[1][:, None]), axis=1)

    return np.abs((np.sum(np.where(check == len(tau), 1, 0)) / B) - 0.95)


def min_alphap(diff, tau):
    B = 1299
    last = ABS_value(get_qtau(1 / B, diff, tau), diff, tau)
    for (index, alphap) in enumerate(np.arange(2, 1299) / 1299):
        qtau = get_qtau(alphap, diff, tau)
        value = ABS_value(qtau, diff, tau)
        if value <= last:
            last = value
            if index == 63:
                return 0.05
        else:
            if index == 0:
                return (index + 1) / B
            if index == 1:
                return (index) / B
            else:
                return (index + 1) / B

# In[]
#### Bandwidth selection

def omega(x, tau):
    return scipy.stats.norm.pdf(x, loc=tau, scale=np.sqrt(0.025))


def estimation_lmcv(vY, mX, h, tau, times, n_est, lmcv_type):
    T = len(vY)
    betahat = np.zeros(shape=(n_est, len(tau)))

    if lmcv_type == 0:
        for i in range(len(tau)):
            new_taut = np.delete(times, i)
            new_mX = np.delete(mX, i, axis=0)
            new_vY = np.delete(vY, i)

            mS, mT = get_mS(tau[i], new_mX, h, new_taut, 2 * n_est), get_mT(tau[i], new_mX, new_vY, h, new_taut,
                                                                            2 * n_est)
            mul = np.linalg.inv(mS) @ mT
            for j in range(n_est):
                betahat[j, i] = mul[j] if j < n_est else 0
    else:
        for i in range(len(tau)):
            deleted_indices = []
            for j in range(lmcv_type + 1):
                deleted_indices.append(i - j)
                deleted_indices.append((i + j) % T)
            new_taut = np.delete(times, deleted_indices)
            new_mX = np.delete(mX, deleted_indices, axis=0)
            new_vY = np.delete(vY, deleted_indices)

            mS, mT = get_mS(tau[i], new_mX, h, new_taut, 2 * n_est), get_mT(tau[i], new_mX, new_vY, h, new_taut,
                                                                            2 * n_est)
            mul = np.linalg.inv(mS) @ mT
            for j in range(n_est):
                betahat[j, i] = mul[j] if j < n_est else 0

    return betahat


def LMCV(betahat_lmcv, mX, vY, one_tau):
    T = len(vY)

    taut = np.arange(1 / T, (T + 1) / T, 1 / T)
    if mX.ndim == 1:
        aa = (vY - (mX * betahat_lmcv)) ** 2
        b = omega(taut, one_tau)

        return np.sum(aa * b) / T
    elif mX.ndim == 2:
        aa = (vY - (mX @ betahat_lmcv).diagonal()) ** 2
        b = omega(taut, one_tau)

        return np.sum(aa * b) / T


def get_optimalh(vY, mX, lmcv_type, n_est):
    T = len(vY)

    taut = np.arange(1 / T, (T + 1) / T, 1 / T)
    optimal_h_tau = []
    vh = np.arange(0.06, 0.2, 0.005)

    betasss = np.zeros(shape=(len(vh), n_est, T))
    for (index, h) in enumerate(vh):
        betasss[index] = estimation_lmcv(vY, mX, h, taut, taut, n_est, lmcv_type)

    for one_tau in taut:
        contain = []

        for (index, h) in enumerate(vh):
            contain.append(LMCV(betasss[index], mX, vY, one_tau))
        optimal_h_tau.append(np.argmin(np.array(contain)))

    return vh[min(optimal_h_tau)]


def BW_sele(vY, mX, n_est):
    T = len(vY)
    h = []
    taut = np.arange(1 / T, (T + 1) / T, 1 / T)
    for lmcv_type in [0, 2, 4, 6]:
        h.append(get_optimalh(vY, mX, lmcv_type, n_est))
    AVG = np.mean(h)
    h.append(AVG)

    return h

# In[]
##### Apply methods to data
def M1_bands(vY, mX, h, n_est, type):
    htilde = 2 * (h ** (5 / 9))
    T = len(vY)
    taut = np.arange(1 / T, (T + 1) / T, 1 / T)
    B = 1299

    betatilde = estimator(vY, mX, htilde, taut, taut, n_est)
    betahat = estimator(vY, mX, h, taut, taut, n_est)

    G1 = taut[:284]
    betatilde_G1 = estimator(vY, mX, htilde, G1, taut, n_est)
    betahat_G1 = estimator(vY, mX, h, G1, taut, n_est)

    G2 = taut[1459:]
    betatilde_G2 = estimator(vY, mX, htilde, G2, taut, n_est)
    betahat_G2 = estimator(vY, mX, h, G2, taut, n_est)

    if n_est == 1:
        zhat = vY - (mX * betatilde[0])
    else:
        zhat = vY - (mX @ betatilde).diagonal()
    betahat_star = np.zeros(shape=(B, n_est, T))
    betahat_star_G1 = np.zeros(shape=(B, n_est, len(G1)))
    betahat_star_G2 = np.zeros(shape=(B, n_est, len(G2)))

    ### For S & SW bootstrap
    if type == 1:
        epsilonhat, max_lag, armodel = AR(zhat, T)
        epsilontilde = epsilonhat - np.mean(epsilonhat)
        for i in range(B):
            vYstar = S_BT(epsilontilde, max_lag, zhat, armodel, mX, betatilde, T)
            betahat_star[i] = estimator(vYstar, mX, h, taut, taut, n_est)
            betahat_star_G1[i] = estimator(vYstar, mX, h, G1, taut, n_est)  ####
            betahat_star_G2[i] = estimator(vYstar, mX, h, G2, taut, n_est)  ####

    elif type == 2:
        epsilontilde, max_lag, armodel = AR(zhat, T)
        for i in range(B):
            vYstar = SW_BT(epsilontilde, max_lag, zhat, armodel, mX, betatilde, T)
            betahat_star[i] = estimator(vYstar, mX, h, taut, taut, n_est)
            betahat_star_G1[i] = estimator(vYstar, mX, h, G1, taut, n_est)  ####
            betahat_star_G2[i] = estimator(vYstar, mX, h, G2, taut, n_est)  ####

    # ### For LBWB bootstrap
    elif type == 3:
        for i in range(B):
            vYstar = LBW_BT(zhat, mX, betatilde, T)
            betahat_star[i] = estimator(vYstar, mX, h, taut, taut, n_est)
            betahat_star_G1[i] = estimator(vYstar, mX, h, G1, taut, n_est)  ####
            betahat_star_G2[i] = estimator(vYstar, mX, h, G2, taut, n_est)  ####

    diff_beta3 = np.zeros(shape=(B, T))
    diff_beta3_G1 = np.zeros(shape=(B, len(G1)))
    diff_beta3_G2 = np.zeros(shape=(B, len(G2)))

    for i in range(B):
        diff_beta3[i] = (betahat_star[i] - betatilde)[3]
        diff_beta3_G1[i] = (betahat_star_G1[i] - betatilde_G1)[3]
        diff_beta3_G2[i] = (betahat_star_G2[i] - betatilde_G2)[3]

    optimal_alphap_1 = min_alphap(diff_beta3, taut)
    optimal_alphap_1_G1 = min_alphap(diff_beta3_G1, G1)
    optimal_alphap_1_G2 = min_alphap(diff_beta3_G2, G2)

    S_LB_beta1 = betahat[3] - get_qtau(optimal_alphap_1, diff_beta3, taut)[1]
    S_UB_beta1 = betahat[3] - get_qtau(optimal_alphap_1, diff_beta3, taut)[0]

    S_LB_beta1_G1 = betahat_G1[3] - get_qtau(optimal_alphap_1_G1, diff_beta3_G1, G1)[1]
    S_UB_beta1_G1 = betahat_G1[3] - get_qtau(optimal_alphap_1_G1, diff_beta3_G1, G1)[0]

    S_LB_beta1_G2 = betahat_G2[3] - get_qtau(optimal_alphap_1_G2, diff_beta3_G2, G2)[1]
    S_UB_beta1_G2 = betahat_G2[3] - get_qtau(optimal_alphap_1_G2, diff_beta3_G2, G2)[0]

    P_LB_beta1 = betahat[3] - get_qtau(0.05, diff_beta3, taut)[1]
    P_UB_beta1 = betahat[3] - get_qtau(0.05, diff_beta3, taut)[0]

    return S_LB_beta1, S_UB_beta1, S_LB_beta1_G1, S_UB_beta1_G1, S_LB_beta1_G2, S_UB_beta1_G2, P_LB_beta1, P_UB_beta1


def M2_bands(vY, mX, h, n_est, type):
    htilde = 2 * (h ** (5 / 9))
    T = len(vY)
    taut = np.arange(1 / T, (T + 1) / T, 1 / T)
    B = 1299

    betatilde = estimator(vY, mX, htilde, taut, taut, n_est)
    betahat = estimator(vY, mX, h, taut, taut, n_est)

    G3 = taut[284:550]
    betatilde_G3 = estimator(vY, mX, htilde, G3, taut, n_est)
    betahat_G3 = estimator(vY, mX, h, G3, taut, n_est)

    G4 = taut[550:847]
    betatilde_G4 = estimator(vY, mX, htilde, G4, taut, n_est)
    betahat_G4 = estimator(vY, mX, h, G4, taut, n_est)

    G5 = taut[847:1191]
    betatilde_G5 = estimator(vY, mX, htilde, G5, taut, n_est)
    betahat_G5 = estimator(vY, mX, h, G5, taut, n_est)

    G6 = taut[1191:1459]
    betatilde_G6 = estimator(vY, mX, htilde, G6, taut, n_est)
    betahat_G6 = estimator(vY, mX, h, G6, taut, n_est)

    if n_est == 1:
        zhat = vY - (mX * betatilde[0])
    else:
        zhat = vY - (mX @ betatilde).diagonal()
    betahat_star = np.zeros(shape=(B, n_est, T))
    betahat_star_G3 = np.zeros(shape=(B, n_est, len(G3)))
    betahat_star_G4 = np.zeros(shape=(B, n_est, len(G4)))
    betahat_star_G5 = np.zeros(shape=(B, n_est, len(G5)))
    betahat_star_G6 = np.zeros(shape=(B, n_est, len(G6)))

    ### For S & SW bootstrap
    if type == 1:
        epsilonhat, max_lag, armodel = AR(zhat, T)
        epsilontilde = epsilonhat - np.mean(epsilonhat)
        for i in range(B):
            vYstar = S_BT(epsilontilde, max_lag, zhat, armodel, mX, betatilde, T)
            betahat_star[i] = estimator(vYstar, mX, h, taut, taut, n_est)
            betahat_star_G3[i] = estimator(vYstar, mX, h, G3, taut, n_est)  ####
            betahat_star_G4[i] = estimator(vYstar, mX, h, G4, taut, n_est)  ####
            betahat_star_G5[i] = estimator(vYstar, mX, h, G5, taut, n_est)  ####
            betahat_star_G6[i] = estimator(vYstar, mX, h, G6, taut, n_est)  #

    elif type == 2:
        epsilontilde, max_lag, armodel = AR(zhat, T)
        for i in range(B):
            vYstar = SW_BT(epsilontilde, max_lag, zhat, armodel, mX, betatilde, T)
            betahat_star[i] = estimator(vYstar, mX, h, taut, taut, n_est)
            betahat_star_G3[i] = estimator(vYstar, mX, h, G3, taut, n_est)  ####
            betahat_star_G4[i] = estimator(vYstar, mX, h, G4, taut, n_est)  ####
            betahat_star_G5[i] = estimator(vYstar, mX, h, G5, taut, n_est)  ####
            betahat_star_G6[i] = estimator(vYstar, mX, h, G6, taut, n_est)  #

    # ### For LBWB bootstrap
    elif type == 3:
        for i in range(B):
            vYstar = LBW_BT(zhat, mX, betatilde, T)
            betahat_star[i] = estimator(vYstar, mX, h, taut, taut, n_est)
            betahat_star_G3[i] = estimator(vYstar, mX, h, G3, taut, n_est)  ####
            betahat_star_G4[i] = estimator(vYstar, mX, h, G4, taut, n_est)  ####
            betahat_star_G5[i] = estimator(vYstar, mX, h, G5, taut, n_est)  ####
            betahat_star_G6[i] = estimator(vYstar, mX, h, G6, taut, n_est)  #

    diff_beta4 = np.zeros(shape=(B, T))
    diff_beta4_G3 = np.zeros(shape=(B, len(G3)))
    diff_beta4_G4 = np.zeros(shape=(B, len(G4)))
    diff_beta4_G5 = np.zeros(shape=(B, len(G5)))
    diff_beta4_G6 = np.zeros(shape=(B, len(G6)))

    for i in range(B):
        diff_beta4[i] = (betahat_star[i] - betatilde)[4]
        diff_beta4_G3[i] = (betahat_star_G3[i] - betatilde_G3)[4]
        diff_beta4_G4[i] = (betahat_star_G4[i] - betatilde_G4)[4]
        diff_beta4_G5[i] = (betahat_star_G5[i] - betatilde_G5)[4]
        diff_beta4_G6[i] = (betahat_star_G6[i] - betatilde_G6)[4]

    optimal_alphap_1 = min_alphap(diff_beta4, taut)
    optimal_alphap_1_G3 = min_alphap(diff_beta4_G3, G3)
    optimal_alphap_1_G4 = min_alphap(diff_beta4_G4, G4)
    optimal_alphap_1_G5 = min_alphap(diff_beta4_G5, G5)
    optimal_alphap_1_G6 = min_alphap(diff_beta4_G6, G6)

    S_LB_beta1 = betahat[4] - get_qtau(optimal_alphap_1, diff_beta4, taut)[1]
    S_UB_beta1 = betahat[4] - get_qtau(optimal_alphap_1, diff_beta4, taut)[0]

    S_LB_beta1_G3 = betahat_G3[4] - get_qtau(optimal_alphap_1_G3, diff_beta4_G3, G3)[1]
    S_UB_beta1_G3 = betahat_G3[4] - get_qtau(optimal_alphap_1_G3, diff_beta4_G3, G3)[0]

    S_LB_beta1_G4 = betahat_G4[4] - get_qtau(optimal_alphap_1_G4, diff_beta4_G4, G4)[1]
    S_UB_beta1_G4 = betahat_G4[4] - get_qtau(optimal_alphap_1_G4, diff_beta4_G4, G4)[0]

    S_LB_beta1_G5 = betahat_G5[4] - get_qtau(optimal_alphap_1_G5, diff_beta4_G5, G5)[1]
    S_UB_beta1_G5 = betahat_G5[4] - get_qtau(optimal_alphap_1_G5, diff_beta4_G5, G5)[0]

    S_LB_beta1_G6 = betahat_G6[4] - get_qtau(optimal_alphap_1_G6, diff_beta4_G6, G6)[1]
    S_UB_beta1_G6 = betahat_G6[4] - get_qtau(optimal_alphap_1_G6, diff_beta4_G6, G6)[0]

    P_LB_beta1 = betahat[4] - get_qtau(0.05, diff_beta4, taut)[1]
    P_UB_beta1 = betahat[4] - get_qtau(0.05, diff_beta4, taut)[0]

    return S_LB_beta1, S_UB_beta1, S_LB_beta1_G3, S_UB_beta1_G3, S_LB_beta1_G4, S_UB_beta1_G4, S_LB_beta1_G5, S_UB_beta1_G5, S_LB_beta1_G6, S_UB_beta1_G6, P_LB_beta1, P_UB_beta1


### M1_with_lag_results
def plot_M1_with_lag_bands(bootstrap_type):
    T = len(vY)
    taut = np.arange(1 / T, (T + 1) / T, 1 / T)
    betahat_m1 = estimator(vY.values, mX, 0.0975, taut, taut, 5)
    S_LB_beta1, S_UB_beta1, S_LB_beta1_G1, S_UB_beta1_G1, S_LB_beta1_G2, S_UB_beta1_G2, P_LB_beta1, P_UB_beta1 = M1_bands(
        vY.values, mX, 0.0975, 5, bootstrap_type)
    matplotlib.rc('xtick', labelsize=20)
    matplotlib.rc('ytick', labelsize=20)
    plt.rc('legend', fontsize=20)
    matplotlib.rcParams['lines.linewidth'] = 1.5
    fig, ax = plt.subplots(figsize=(12, 4))

    ax.plot(date[1:], betahat_m1[3], color='black', label='$\hat{\gamma}_{3}(\cdot)$')
    ax.plot(date[1:], S_LB_beta1, color='red', label='ST(FS)')
    ax.plot(date[1:], S_UB_beta1, color='red')

    ax.plot(date[1:285], S_LB_beta1_G1, color='green', label='ST(G)')
    ax.plot(date[1:285], S_UB_beta1_G1, color='green')
    ax.plot(date[1460:], S_LB_beta1_G2, color='green')
    ax.plot(date[1460:], S_UB_beta1_G2, color='green')
    ax.fill_between(date[1:], P_LB_beta1, P_UB_beta1, color='lightgrey', label='PW')
    ax.plot(date, np.zeros(1778))

    ax.axvline(date[284], color='grey', label='break points')
    ax.axvline(date[550], color='grey')
    ax.axvline(date[847], color='grey')
    ax.axvline(date[1191], color='grey')
    ax.axvline(date[1459], color='grey')
    ax.grid(linestyle='dashed')
    ax.legend(frameon=False, fontsize=12)
    plt.show()


### M1_without_lag_results
def plot_M1_no_lag_bands(bootstrap_type):
    T = len(vY11)
    taut = np.arange(1 / T, (T + 1) / T, 1 / T)
    betahat_m1 = estimator(vY11.values, mXX, 0.0975, taut, taut, 4)
    S_LB_beta1, S_UB_beta1, S_LB_beta1_G1, S_UB_beta1_G1, S_LB_beta1_G2, S_UB_beta1_G2, P_LB_beta1, P_UB_beta1 = M1_bands(
        vY11.values, mXX, 0.0975, 4, bootstrap_type)
    matplotlib.rc('xtick', labelsize=20)
    matplotlib.rc('ytick', labelsize=20)
    plt.rc('legend', fontsize=20)
    matplotlib.rcParams['lines.linewidth'] = 1.5
    fig, ax = plt.subplots(figsize=(12, 4))

    ax.plot(date, betahat_m1[3], color='black', label='$\hat{\gamma}_{3}(\cdot)$')
    ax.plot(date, S_LB_beta1, color='red', label='ST(FS)')
    ax.plot(date, S_UB_beta1, color='red')

    ax.plot(date[1:285], S_LB_beta1_G1, color='green', label='ST(G)')
    ax.plot(date[1:285], S_UB_beta1_G1, color='green')
    ax.plot(date[1459:], S_LB_beta1_G2, color='green')
    ax.plot(date[1459:], S_UB_beta1_G2, color='green')
    ax.fill_between(date, P_LB_beta1, P_UB_beta1, color='lightgrey', label='PW')
    ax.plot(date, np.zeros(1778))

    ax.axvline(date[284], color='grey', label='break points')
    ax.axvline(date[550], color='grey')
    ax.axvline(date[847], color='grey')
    ax.axvline(date[1191], color='grey')
    ax.axvline(date[1459], color='grey')
    ax.grid(linestyle='dashed')
    ax.legend(frameon=False, fontsize=12, loc='upper right')
    plt.show()


### M2_with_lag_results
def plot_M2_with_lag_bands(bootstrap_type):
    T = len(vY)
    taut = np.arange(1 / T, (T + 1) / T, 1 / T)
    betahat_m2 = estimator(vY.values, mX1, 0.0975, taut, taut, 6)
    S_LB_beta1_2, S_UB_beta1_2, S_LB_beta1_G3_2, S_UB_beta1_G3_2, S_LB_beta1_G4_2, S_UB_beta1_G4_2, S_LB_beta1_G5_2, S_UB_beta1_G5_2, S_LB_beta1_G6_2, S_UB_beta1_G6_2, P_LB_beta1_2, P_UB_beta1_2 = M2_bands(
        vY.values, mX1, 0.0975, 6, bootstrap_type)
    matplotlib.rc('xtick', labelsize=20)
    matplotlib.rc('ytick', labelsize=20)
    plt.rc('legend', fontsize=20)
    matplotlib.rcParams['lines.linewidth'] = 1.5
    fig, ax = plt.subplots(figsize=(12, 4))

    ax.plot(date[1:], betahat_m2[4], color='black', label='$\hat{\gamma}_{4}(\cdot)$')
    ax.plot(date[1:], S_LB_beta1_2, color='red', label='ST(FS)')
    ax.plot(date[1:], S_UB_beta1_2, color='red')

    ax.plot(date[286:552], S_LB_beta1_G3_2[:266], color='green', label='ST(G)')
    ax.plot(date[286:552], S_UB_beta1_G3_2[:266], color='green')
    #
    ax.plot(date[551:848], S_LB_beta1_G4_2[:297], color='green')
    ax.plot(date[551:848], S_UB_beta1_G4_2[:297], color='green')

    ax.plot(date[848:1192], S_LB_beta1_G5_2[:344], color='green')
    ax.plot(date[848:1192], S_UB_beta1_G5_2[:344], color='green')
    #
    ax.plot(date[1192:1460], S_LB_beta1_G6_2[:268], color='green')
    ax.plot(date[1192:1460], S_UB_beta1_G6_2[:268], color='green')
    ax.fill_between(date[1:], P_LB_beta1_2, P_UB_beta1_2, color='lightgrey', label='PW')

    ax.plot(date, np.zeros(1778))

    ax.axvline(date[284], color='grey', label='break points')
    ax.axvline(date[550], color='grey')
    ax.axvline(date[847], color='grey')
    ax.axvline(date[1191], color='grey')
    ax.axvline(date[1459], color='grey')
    ax.grid(linestyle='dashed')
    ax.legend(frameon=False, fontsize=12)
    plt.show()


### M2_without_lag_results
def plot_M2_no_lag_bands(bootstrap_type):
    T = len(vY11)
    taut = np.arange(1 / T, (T + 1) / T, 1 / T)
    betahat_m2 = estimator(vY11.values, mX11, 0.0975, taut, taut, 5)
    S_LB_beta1_2, S_UB_beta1_2, S_LB_beta1_G3_2, S_UB_beta1_G3_2, S_LB_beta1_G4_2, S_UB_beta1_G4_2, S_LB_beta1_G5_2, S_UB_beta1_G5_2, S_LB_beta1_G6_2, S_UB_beta1_G6_2, P_LB_beta1_2, P_UB_beta1_2 = M2_bands(
        vY11.values, mX11, 0.0975, 5, bootstrap_type)
    matplotlib.rc('xtick', labelsize=20)
    matplotlib.rc('ytick', labelsize=20)
    plt.rc('legend', fontsize=20)  # using a size in points
    matplotlib.rcParams['lines.linewidth'] = 1.5
    fig, ax = plt.subplots(figsize=(12, 4))  # Adjust the width (12) and height (4) as desired

    ax.plot(date, betahat_m2[4], color='black', label='$\hat{\gamma}_{4}(\cdot)$')
    ax.plot(date, S_LB_beta1_2, color='red', label='ST(FS)')
    ax.plot(date, S_UB_beta1_2, color='red')

    ax.plot(date[286:552], S_LB_beta1_G3_2[:266], color='green', label='ST(G)')
    ax.plot(date[286:552], S_UB_beta1_G3_2[:266], color='green')
    #
    ax.plot(date[551:848], S_LB_beta1_G4_2[:297], color='green')
    ax.plot(date[551:848], S_UB_beta1_G4_2[:297], color='green')

    ax.plot(date[848:1192], S_LB_beta1_G5_2[:344], color='green')
    ax.plot(date[848:1192], S_UB_beta1_G5_2[:344], color='green')
    #
    ax.plot(date[1192:1460], S_LB_beta1_G6_2[:268], color='green')
    ax.plot(date[1192:1460], S_UB_beta1_G6_2[:268], color='green')
    ax.fill_between(date, P_LB_beta1_2, P_UB_beta1_2, color='lightgrey', label='PW')

    ax.plot(date, np.zeros(1778))

    ax.axvline(date[284], color='grey', label='break points')
    ax.axvline(date[550], color='grey')
    ax.axvline(date[847], color='grey')
    ax.axvline(date[1191], color='grey')
    ax.axvline(date[1459], color='grey')
    ax.grid(linestyle='dashed')
    ax.legend(frameon=False, fontsize=12)

    plt.show()


#################### import data
df = pd.read_csv("Path for CN HERDING DATA")
date = df['Date']
date = pd.to_datetime(date)
CSAD = df["CSAD_AVG"]
MRTN = df["AVG_RTN"]
CSI300 = df["SHSZ300"]
MRTN_abs = np.abs(MRTN)
MRTN_2 = MRTN ** 2
CSI300_2 = CSI300 ** 2
mX = np.zeros(shape=(1777, 5))
mX[:, 0] = np.ones(1777)
mX[:, 1] = MRTN[1:]
mX[:, 2] = MRTN_abs[1:]
mX[:, 3] = MRTN_2[1:]
mX[:, 4] = CSAD[:1777]
mXX = np.zeros(shape=(1778, 4))
mXX[:, 0] = np.ones(1778)
mXX[:, 1] = MRTN
mXX[:, 2] = MRTN_abs
mXX[:, 3] = MRTN_2

mX1 = np.zeros(shape=(1777, 6))
mX1[:, 0] = np.ones(1777)
mX1[:, 1] = MRTN[1:]
mX1[:, 2] = MRTN_abs[1:]
mX1[:, 3] = MRTN_2[1:]
mX1[:, 4] = CSI300_2[1:]
mX1[:, 5] = CSAD[:1777]
mX11 = np.zeros(shape=(1778, 5))
mX11[:, 0] = np.ones(1778)
mX11[:, 1] = MRTN
mX11[:, 2] = MRTN_abs
mX11[:, 3] = MRTN_2
mX11[:, 4] = CSI300_2
vY11 = CSAD
vY = CSAD[1:]

#################### plot the figures of bands. Bootstrap_type = {1, 2, 3}, where 1 = SB, 2 = SWB, 3 = LBWB.

# plot_M1_with_lag_bands(bootstrap_type)
# plot_M1_no_lag_bands(bootstrap_type)
# plot_M2_with_lag_bands(bootstrap_type)
# plot_M2_no_lag_bands(bootstrap_type)
