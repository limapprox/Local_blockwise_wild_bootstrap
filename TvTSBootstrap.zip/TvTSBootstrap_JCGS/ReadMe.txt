========================================================================================================================

This is the ReadMe file for the codes and datasets to replicate the results presented in the paper:

'Bootstrap inference for linear time-varying coefficient models in locally stationary time series'

Authors: Yicong Lin, Mingxuan Song, Bernhard van der Sluis
========================================================================================================================



The code requires several Python packages: os, joblib, numpy, statsmodels, math, matplotlib.

The library contains the following folders:

- Simulations: contains the .py scripts to reproduce the Monte Carlo study in the paper. Each sub-folder is labeled by the setting associated with the simulations.
We consider three different data generating processes for the regressors, each labeled according to the filename: (i) no unit roots, labeled AR_S; (ii) time-varying cointegration, labeled AR_PS; and (iii) two unit roots, labeled AR_NS.
	- linear: contains the code for the linear regression model, sample size n=200.
		- code for autoregressive errors (AR): in folder AR
		- code for endogenous errors (ENDO): in folder ENDO
		- code for conditionally heteroskedastic errors (GARCH1 and GARCH2): in folder GARCH
		- code for nonlinear dependent errors (NL1 and NL2): in folder NS

	- n400: contains the code for the linear regression model, sample size n=400.
		- code for AR errors: AR_S_400.py
		- code for NL1 errors: NL1_S_400.py
		- code for NL2 errors: NL2_S_400.py

	- bandwidth: contains the code for the bandwidth selection LMCV in the linear regression model, sample size n=200.
		- code for AR errors: BW_AR_S.py
		- code for GARCH1 errors: BW_GARCH1_S.py
		- code for NL1 errors: BW_NL1_S.py
		- code for NL2 errors: BW_NL2_S.py


	- nonparametric: contains the code for the fully nonparametric model, sample size n=200.
		- code for setting 1 (f(\tau) = \tau^2): nonparametric_setting_1.py
		- code for setting 2 (f(\tau) = \exp(\tau)): nonparametric_setting_2.py

	- tvautoregressive: contains the code for the time-varying autoregressive model, sample size n=200.
		- code for setting 1 (f(x) = 0.8*\sin(2*\pi*x)): tvautoregressive_setting_1.py
		- code for setting 2 (f(x) = 0.5*\exp(x-0.5)): tvautoregressive_setting_2.py


- Empirics: contains the .py scripts and datasets to reproduce the empirical studies in the paper. Each empirical case study is associated with its sub-folder.
	- herding: contains the .py scripts and datasets to reproduce the case study on herding effects in Section 5.
		- herding data: CN HERDING.csv
		- code: TvTSBootstrap_Herding.py

	- consumption: contains the .py scripts and datasets to reproduce the case study on consumption behavior in Appendix E.
		- consumption data: FredData.xlsx
		- code: TvTSBootstrap_Consumption.py

- TvTSBootstrap: contains the code for general purpose of the methods proposed in the paper.
	- code: TvTSBootstrap_toUse.py

For detailed descriptions of the methods in the code, we refer the user to the file TvTSBootstrap_toUse.py in the folder TvTSBootstrap.

========================================================================================================================

This version: April 29, 2024


Copyright: Yicong Lin, Mingxuan Song, Bernhard van der Sluis

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License
as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

========================================================================================================================











