# Copyright: Yicong Lin, Mingxuan Song, Bernhard van der Sluis
#
# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

# ==================================================#
# Researchers are free to use the code.
# Please cite the following papers:
# 1. Yicong Lin, Mingxuan Song and Bernhard van der Sluis (2024). Bootstrap inference for linear time-varying coefficient models in locally stationary time series.
# 2. Marina Friedrich and Yicong Lin (2024). Sieve bootstrap inference for linear time-varying coefficient models. Journal of Econometrics.

# Purpose: Simulation for linear model, NL1 errors and regressor with (\lambda_1, \lambda_2) = (1, 1), data size n = 200.

import os
os.environ['MKL_NUM_THREADS']='1' 
os.environ['OMP_NUM_THREADS']='1'
import numpy as np
# import matplotlib.pyplot as plt
import pandas as pd
from statsmodels.tsa.ar_model import ar_select_order
from joblib import Parallel, delayed
from statsmodels.tsa.ar_model import AutoReg
import math
from scipy.linalg import fractional_matrix_power
from arch import arch_model
import warnings
warnings.filterwarnings('ignore')

alpha = 0.05
T = 200
n = T
taut = np.arange(1 / T, (T + 1) / T, 1 / T)
dSqrt2 = np.sqrt(2)
d2Sqrt2 = 2*dSqrt2

def beta1(tau):
    return 1.5 * np.exp(-10 * (tau - 0.2) ** 2) + 1.6 * np.exp(-8 * (tau - 0.8) ** 2)

def beta2(tau):
    return -0.5 * tau - 0.5 * np.exp(-5 * (tau - 0.8) ** 2)

def g(tau):
    return - 6 * tau - 4 * tau ** 3 + 9 * tau ** 2 + 2

######### xi Generator #########

def get_H_xi(i, v_zeta):
    value = a(taut[i])
    contain = np.zeros(shape=(500,2))
    for j in range(500):
        contain[j] = (value ** j) * v_zeta[i - j + 500]
    return np.sum(contain,axis=0) / 4

def generatevxi():

    v_zeta = np.random.multivariate_normal([0, 0], np.array([[1, 0], [0, 1]]), size=700)
    vxi = np.zeros(shape=(200,2))
    for i in range(200):
        vxi[i] = get_H_xi(i, v_zeta)
    return vxi


######### stationary X Generator #########
def generateX_s(vxi):
    U = np.random.uniform(0, 1, 4).reshape(2, 2)
    H = U @ fractional_matrix_power(U.T @ U, -0.5)
    lambda1 = 0.3
    lambda2 = 0.2
    mLam = np.array([[lambda1, 0], [0, lambda2]])
    A = (H @ mLam) @ H.T
    mX = np.zeros(shape=(T, 2))
    mX[0] = np.array([0, 0])
    for i in range(1, T):
        mX[i] = (A @ mX[i - 1] + vxi[i-1])

    return mX


######### partly-stationary X Generator #########
def generateX_ps(vxi):
    U = np.random.uniform(0, 1, 4).reshape(2, 2)
    H = U @ fractional_matrix_power(U.T @ U, -0.5)
    lambda1 = 1
    lambda2 = 0.2
    mLam = np.array([[lambda1, 0], [0, lambda2]])
    A = (H @ mLam) @ H.T
    mX = np.zeros(shape=(T, 2))
    mX[0] = np.array([0, 0])
    for i in range(1, T):
        mX[i] = (A @ mX[i - 1] + vxi[i-1])

    return mX


######### nonstationary X Generator #########
def generateX_ns(vxi):
    U = np.random.uniform(0, 1, 4).reshape(2, 2)
    H = U @ fractional_matrix_power(U.T @ U, -0.5)
    lambda1 = 1
    lambda2 = 1
    mLam = np.array([[lambda1, 0], [0, lambda2]])
    A = (H @ mLam) @ H.T
    mX = np.zeros(shape=(T, 2))
    mX[0] = np.array([0, 0])
    for i in range(1, T):
        mX[i] = (A @ mX[i - 1] + vxi[i-1])

    return mX


######### U Generator #########
def generateU():
    u_0 = 0
    vU = np.zeros(T)
    phi = 0.3
    psi = 0
    epsilon = np.random.normal(0, np.sqrt((1 - phi ** 2) / (2 * (1 + psi ** 2 + 2 * psi * phi))), T)
    for i in range(1, T):
        vU[i] = phi * u_0 + epsilon[i] + psi * epsilon[i - 1]

        u_0 = vU[i]
    return vU

######### Garch U Generator #########
def generateU_hete_garch():
    # Define the parameters of the GARCH model
    omega = 0.1
    alpha = 0.2
    beta = 0.7

    # Create a GARCH process
    garch = arch_model(None, mean='Zero', vol='GARCH', p=1, o=0, q=1)
    res = garch.simulate([omega, alpha, beta], T)

    return res.data.values


######### Endo case, X and U Generator #########
def generate_endo():
    vU = np.zeros(T + 500)
    phi = 0.3
    psi = 0

    rho = 0.3
    correlated_erros = np.random.multivariate_normal([0, 0, 0], np.array(
        [[1, rho, rho ** 2], [rho, 1, rho], [rho ** 2, rho, (1 - phi ** 2) / (2 * (1 + psi ** 2 + 2 * psi * phi))]]),
                                                     size=T + 500)

    epsilon = correlated_erros[:, 2]
    for i in range(1, T + 500):
        vU[i] = phi * vU[i - 1] + epsilon[i]

    vxi = np.array(correlated_erros[:, :2])
    varerros = np.zeros(shape=(200, 2))
    for i in range(200):
        varerros[i] = get_H_xi(i, vxi)

    U = np.random.uniform(0, 1, 4).reshape(2, 2)
    H = U @ fractional_matrix_power(U.T @ U, -0.5)
    lambda1 = 1
    lambda2 = 1
    mLam = np.array([[lambda1, 0], [0, lambda2]])
    A = (H @ mLam) @ H.T
    mX = np.zeros(shape=(T, 2))
    mX[0] = np.array([np.random.normal(0, 1, 1).sum(), np.random.normal(0, 1, 1).sum()])

    for i in range(1, T):
        mX[i] = (A @ mX[i - 1] + varerros[i - 1])

    vY = beta1(taut) * mX[:, 0] + beta2(taut) * mX[:, 1] + vU[500:]
    return vY, mX


######### Simulation Data #########
def simulateData(vxi):
    vU, mX = generateU(), generateX_ns(vxi)
    vY = beta1(taut) * mX[:, 0] + beta2(taut) * mX[:, 1] + vU

    return vY, mX


######### Zhou & Wu Generation #########
def a(tau):
    return 1 / 2 - (tau - 0.5) ** 2

def c(tau):
    return 1 / 4 + tau / 2

def get_H(i, v_zeta):
    value = a(taut[i])
    contain = np.zeros(500)
    for j in range(500):
        contain[j] = (value ** j) * v_zeta[i - j + 500]
    return np.sum(contain) / 4

def get_G(i, v_zeta_1):
    value = c(taut[i])
    contain = np.zeros(500)
    for j in range(500):
        contain[j] = (value ** j) * v_zeta_1[i - j + 500]
    return np.sum(contain)

def generateU_ZW_inde(v_zeta):
    vU = np.zeros(200)
    for i in range(200):
        vU[i] = get_H(i, v_zeta)
    return vU

def generateU_ZW_hetero(v_zeta, v_zeta_1):
    vU = np.zeros(200)
    for i in range(200):
        vU[i] = (4 * get_H(i, v_zeta)) * (get_G(i, v_zeta_1))
    return vU / 8

def simulateData_ZW(vxi):
    v_zeta = np.random.normal(0, 1, 700)
    # v_zeta_1=np.random.normal(0,1,700)

    vU, mX = generateU_ZW_inde(v_zeta), generateX_ns(vxi)

    vY = beta1(taut) * mX[:, 0] + beta2(taut) * mX[:, 1] + vU
    return vY, mX


######### Estimation #########
def K(u):
    return np.where(np.abs(u) <= 1, 0.75 * (1 - u ** 2), 0)

def K_ZW_Q(vTi_t, h):
    return d2Sqrt2*K(dSqrt2*vTi_t/h) - K(vTi_t/h)


def Sn(k, tau, mX, h, times):
    u = (times[None, :] - tau) / h
    K_u = K(u)

    return np.sum((mX[:, None, :] * mX[:, :, None]) * np.reshape(((times[None, :] - tau) ** k) * K_u,
                                                                 newshape=(len(times), 1, 1)), axis=0) / (h)

def Tn(k, tau, mX, vY, h, times):
    u = (times[None, :] - tau) / h
    K_u = K(u)

    return np.sum(
        mX[:, :, None] * np.reshape((times[None, :] - tau) ** k * K_u, newshape=(len(times), 1, 1)) * vY.reshape(T, 1,
                                                                                                                 1),
        axis=0) / (h)

def get_mS(tau, mX, h, times):
    mS = np.zeros(shape=(4, 4))
    Sn0 = Sn(0, tau, mX, h, times)
    Sn1 = Sn(1, tau, mX, h, times)
    Sn2 = Sn(2, tau, mX, h, times)
    size = Sn0.shape[0]
    mS[:size, :size] = Sn0
    mS[:size, size:] = Sn1
    mS[size:, :size] = Sn1.T
    mS[size:, size:] = Sn2

    return mS

def get_mT(tau, mX, vY, h, times):
    mT = np.zeros(shape=(4, 1))
    Tn0 = Tn(0, tau, mX, vY, h, times)
    Tn1 = Tn(1, tau, mX, vY, h, times)
    size = Tn0.shape[0]

    mT[:size, 0] = Tn0[:, 0]
    mT[size:, 0] = Tn1[:, 0]

    return mT

def estimator(vY, mX, h, tau, times):
    betahat = np.zeros(shape=(2, len(tau)))
    for i in range(len(tau)):
        mS, mT = get_mS(tau[i], mX, h, times), get_mT(tau[i], mX, vY, h, times)
        mul = np.linalg.inv(mS) @ mT
        betahat[:, i][0] = mul[0]
        betahat[:, i][1] = mul[1]

    return betahat

######### Bandwidth Selection #########
def bandwth_selection(vY, mX, betahat):
    vYfit = betahat[0] * mX[:, 0] + betahat[1] * mX[:, 1]
    Q_h = (((vY.reshape(1, T)) @ vY) ** (-1)) * (vYfit.reshape(T, 1) @ vY.reshape(1, T))
    sigma_hat2 = np.sum((vYfit - vY) ** 2) / n
    AIC = np.log(sigma_hat2) + (2 * (np.matrix.trace(Q_h) + 1)) / (n - np.matrix.trace(Q_h) - 2)
    print(sigma_hat2)
    GCV = sigma_hat2 / (1 - np.matrix.trace(Q_h) / n) ** 2
    return AIC, GCV


######### Bootstrap Setup #########
def AR(zhat):
    maxp = 10 * np.log10(200)
    arm_selection = ar_select_order(zhat, ic='aic', trend='n', maxlag=int(maxp))

    if arm_selection.ar_lags is None:  ######
        armodel = AutoReg(zhat, trend='n', lags=0).fit()
        max_lag = 0  ## to avoid the nonetype error
        epsilonhat = zhat
        #epsilontilde = epsilonhat #- np.mean(epsilonhat)
    else:
        armodel = arm_selection.model.fit()
        max_lag = max(arm_selection.ar_lags)
        epsilonhat = armodel.resid
        #epsilontilde = epsilonhat #- np.mean(epsilonhat)

    return epsilonhat, max_lag, armodel
# In[]
######### Sieve Bootstrap #########
def S_BT(epsilontilde, max_lag, zhat, armodel, mX, betatilde):
    epsilonstar = np.random.choice(epsilontilde, T - max_lag + 50)
    if max_lag == 0:
        zstar = epsilonstar[50:]
        zstar_array = zstar
    else:

        max_lag = np.arange(1, max_lag + 1)

        zstar_array = get_Zstar_AR(max_lag, armodel, 200, epsilonstar)

    vYstar = (mX @ betatilde + zstar_array).diagonal()

    return vYstar

######### Sieve Wild Bootstrap #########
def SW_BT(epsilontilde, max_lag, zhat, armodel, mX, betatilde):
    epsilonstar = epsilontilde * np.random.normal(0, 1, T - max_lag)
    epsilonstar = np.random.choice(epsilonstar, T - max_lag + 50)
    if max_lag == 0:
        zstar = epsilonstar[50:]
        zstar_array = zstar

    else:

        max_lag = np.arange(1, max_lag + 1)

        zstar_array = get_Zstar_AR(max_lag, armodel, 200, epsilonstar)

    vYstar = (mX @ betatilde + zstar_array).diagonal()

    return vYstar

def get_Zstar_AR(max_lags, armodel, T, epsilonstar):
    # Initialize the AR process with the known initial values
    zstar = np.zeros(len(max_lags))

    # Add the AR component for each lag value and coefficient
    for i in range(len(max_lags), T):
        ar_component = 0
        for j, lag in enumerate(max_lags):
            lagged_data = zstar[i - lag]
            ar_component += armodel.params[j] * lagged_data

        ar_component += epsilonstar[i + 20 - len(max_lags)]

        zstar = np.append(zstar, ar_component)

    return zstar


######### Local Moving Block Wild Bootstrap #########
def LBW_BT(zhat, mX, betatilde, h):
    l = int(4.5 * (T*h) ** (1 / 4))

    number_blocks = T - l + 1
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        overlapping_blocks[i] = np.array(zhat[i:i + l]).reshape(l, 1)

    zstar = np.zeros(shape=(l*int(np.ceil(T/l)), 1))
    for tau in range(0, T, l):
        # local_number_blocks = l if tau in [0, T - l] else 2 * l
        local_number_blocks = np.shape(overlapping_blocks[max(tau - l, 0):tau + l])[0]
        random_choice = np.random.choice(np.arange(0, local_number_blocks), 1)
        vWild = np.repeat(np.random.normal(0, 1, 1), l)
        overlapping_blocks_star = (overlapping_blocks[max(tau - l, 0):tau + l])[random_choice]
        zstar[tau:tau + l] = overlapping_blocks_star.reshape(l, 1) * vWild.reshape(l, 1)  ## wild part

    zstar = zstar[:T]

    vYstar = (mX @ betatilde + zstar).diagonal()
    

    return vYstar


######### Non-overlapping Block Bootstrap #########
def NB_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = int(200/l)
    non_overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        non_overlapping_blocks[i] = np.array(zhat[(i)*10:(i+1)*10]).reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=number_blocks)
    non_overlapping_blocks_star = non_overlapping_blocks[random_choice]
    zstar = non_overlapping_blocks_star.reshape(200, 1)

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar


######### Circular Block Bootstrap #########
def CB_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = 200
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    extended_zhat = np.concatenate((zhat, zhat[:l - 1]))

    for i in range(number_blocks):
        start_idx = i % len(zhat)
        end_idx = start_idx + l

        block = extended_zhat[start_idx:end_idx]
        overlapping_blocks[i] = block.reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=int(200 / l))
    overlapping_blocks_star = overlapping_blocks[random_choice]
    zstar = overlapping_blocks_star.reshape(200, 1)

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar


######### Moving Block Wild Bootstrap #########
def BW_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = 200 - l + 1
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        overlapping_blocks[i] = np.array(zhat[i:i + l]).reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=int(200 / l))
    vWild = np.repeat(np.random.normal(0, 1, 20), 10)
    overlapping_blocks_star = overlapping_blocks[random_choice]
    zstar = overlapping_blocks_star.reshape(200, 1)*vWild.reshape(200,1)## wild part

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Circular Block Wild Bootstrap #########
def CBW_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = 200
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    extended_zhat = np.concatenate((zhat, zhat[:l - 1]))

    for i in range(number_blocks):
        start_idx = i % len(zhat)
        end_idx = start_idx + l

        block = extended_zhat[start_idx:end_idx]
        overlapping_blocks[i] = block.reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=int(200 / l))
    vWild = np.repeat(np.random.normal(0, 1, 20), 10)
    overlapping_blocks_star = overlapping_blocks[random_choice]
    zstar = overlapping_blocks_star.reshape(200, 1)*vWild.reshape(200,1)## wild part

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Non-overlapping Block Wild Bootstrap #########
def NBW_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = int(200/l)
    non_overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        non_overlapping_blocks[i] = np.array(zhat[(i)*10:(i+1)*10]).reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=number_blocks)
    vWild = np.repeat(np.random.normal(0, 1, 20), 10)
    non_overlapping_blocks_star = non_overlapping_blocks[random_choice]
    zstar = non_overlapping_blocks_star.reshape(200, 1)*vWild.reshape(200,1)## wild part

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Simutaneous Bands #########
def get_qtau(alphap, diff, tau):
    qtau = np.zeros(shape=(2, len(tau)))
    for i in range(len(tau)):
        qtau[0, i] = np.quantile(diff[:, i], alphap / 2)

        qtau[1, i] = np.quantile(diff[:, i], (1 - alphap / 2))
    return qtau

def ABS_value(qtau, diff, tau):
    B = 1299
    check = np.sum((qtau[0][:, None] < diff[:, :, None]) & (diff[:, :, None] < qtau[1][:, None]), axis=1)

    return np.abs((np.sum(np.where(check == len(tau), 1, 0)) / B) - 0.95)

def min_alphap(diff, tau):
    B = 1299
    last = ABS_value(get_qtau(1 / B, diff, tau), diff, tau)
    # print(last)
    for (index, alphap) in enumerate(np.arange(2, 1299) / 1299):
        qtau = get_qtau(alphap, diff, tau)
        value = ABS_value(qtau, diff, tau)
        if value <= last:
            last = value
            if index == 63:
                return 0.05
        else:
            if index == 0:
                return (index + 1) / B
            if index == 1:
                return (index) / B
            else:
                return (index + 1) / B

# In[]
# @njit
def getQ(B, T, taut, h, alpha):
    h = h*2 
    mV = np.random.normal(0,1,(T,B))
    vQ = np.zeros(B)
    mMu = np.zeros((T,B))
    
    mTi_t = np.repeat(taut, T).reshape((-1,T)) - taut
    
    dDenum = T*h
    
    for i in range(B):
        for t in range(1,T+1):
            vMu = mMu[:,i]
            vTi_t = mTi_t[:,t-1]
            vV = mV[:,i]
            vKernel = K_ZW_Q(vTi_t, h)
            vMu[t-1] = vV @ vKernel
        vQ[i] = max(np.absolute(vMu))/dDenum
    dQ = np.quantile(vQ, 1-alpha)
    return dQ
 
# @njit
def getLambda(mmDelta, iN, iM, taut, dT, dTau,dGamma):
    if dT <= dGamma:
        dT = dGamma
    if dT >= 1-dGamma:
        dT = 1-dGamma
    vTi_t = taut - dT
    vKernel = K(vTi_t/dTau)
    
    vWeights = vKernel/np.sum(vKernel)
    mLam = np.zeros((mmDelta.shape[0], mmDelta.shape[1]))
    for i in range(T):
        mLam = mLam + vWeights[i]*mmDelta[:,:,i]
    return mLam

# @njit
def getDelta(mX, vEps, iM):
    mX = mX.T
    mL = vEps * mX
    mL = mL.T
    (iP, T) = mX.shape
    dDenum=2*iM+1
    mmDelta = np.zeros((iP, iP, T))
    for i in range(0, T):
        mQi = (np.sum(mL[max(0,i-iM):min(i+iM,T),:], axis=0)).reshape(-1,1)
        mDeltai = (mQi @ mQi.T)/dDenum
        mmDelta[:,:,i] = mDeltai 
    return mmDelta

# @njit
def getSigma(mM, mLam):
    mM_inv = np.linalg.inv(mM)
    vSigma = np.array([mM_inv[d,d] * np.sqrt(mLam[d,d]) for d in range(mLam.shape[0])])
    return vSigma

# @njit
def getM(mX, T, dT, h):
    vTi_t = np.arange(1, T+1)/T - dT
    vKernel = K(vTi_t/h)
    mX_tilde = mX*(np.sqrt(vKernel).reshape(-1,1))
    mM = mX_tilde.T@mX_tilde/(T*h)
    return mM

######### MC - Zhou and Wu (2010) Simulation-based method
def MC_ZW(h, vY, mX, sBName):
    # initialisation
    alpha = 0.05
    T = 200
    B = 3000
    
    # parameter specification
    iM = int((T)**(2/7))
    dTau = (T)**(-1/7)
    dGamma = dTau + (iM+1)/T
    taut = np.arange(1/T, (T+1)/T, 1/T)
    
    # G sets
    G, G_sub, len_G, len_Gsub = G_sample(h)
    
    # estimation
    betahat = estimator(vY, mX, h, taut, taut)
    
    # Jackknife bias-corrected estimator
    h_jk = 2*h
    betahat_j = estimator(vY, mX, h_jk, taut, taut)
    betahat_k = estimator(vY, mX, h_jk/np.sqrt(2), taut, taut)
    betahat_jk = 2*betahat_k - betahat_j
    
    # simulation quantile
    dQ = getQ(B, T, taut, h, alpha)
    
    # estimating LRV
    vEps = vY - (mX @ betahat).diagonal()
    mmDelta = getDelta(mX, vEps, iM)        
    
    vT_star = np.maximum(np.array([h]*T), np.minimum(taut,1-h))
    
    mmSCT = np.zeros((T, 2, mX.shape[1]))
    
    for l in range(T):
        # construct mMHat(tau)
        mM = getM(mX, T, vT_star[l], h)
        
        # construct mLambdaTilde(tau)
        mLam = getLambda(mmDelta, T, iM, taut, taut[l], dTau, dGamma)
        
        # construct LRV
        vSigma = getSigma(mM, mLam)
        for d in range(mX.shape[1]):
            mmSCT[l,:,d] = betahat_jk[d,l] + vSigma[d]*dQ*np.array([-1,1])
    
    # compute coverage
    LB_beta1 = mmSCT[:,0,0]
    UB_beta1 = mmSCT[:,1,0]
    if np.sum((LB_beta1 < (beta1(taut))) & ((beta1(taut)) < UB_beta1)) == T:
        if_cover_1 = 1
    else:
        if_cover_1 = 0
                        

    LB_beta1_G = mmSCT[np.floor(G*T).astype(int),0,0]
    UB_beta1_G = mmSCT[np.floor(G*T).astype(int),1,0]
    if np.sum((LB_beta1_G < (beta1(G))) & ((beta1(G)) < UB_beta1_G)) == len(G):
        if_cover_1_G = 1
    else:
        if_cover_1_G = 0
        
        
    LB_beta1_Gsub = mmSCT[np.floor(G_sub*T).astype(int),0,0]
    UB_beta1_Gsub = mmSCT[np.floor(G_sub*T).astype(int),1,0]
    if np.sum((LB_beta1_Gsub < (beta1(G_sub))) & ((beta1(G_sub)) < UB_beta1_Gsub)) == len(G_sub):
        if_cover_1_Gsub = 1
    else:
        if_cover_1_Gsub = 0

    ######## Pointiwse band beta1
    P_LB_beta1 = LB_beta1
    P_UB_beta1 = UB_beta1

    ######
    ###### Simul band beta2
    LB_beta2 = mmSCT[:,0,1]
    UB_beta2 = mmSCT[:,1,1]
    if np.sum((LB_beta2 < (beta2(taut))) & ((beta2(taut)) < UB_beta2)) == T:
        if_cover_2 = 1
    else:
        if_cover_2 = 0
        
    
    LB_beta2_G = mmSCT[np.floor(G*T).astype(int),0,1]
    UB_beta2_G = mmSCT[np.floor(G*T).astype(int),1,1]
    if np.sum((LB_beta2_G < (beta2(G))) & ((beta2(G)) < UB_beta2_G)) == len(G):
        if_cover_2_G = 1
    else:
        if_cover_2_G = 0
        
    LB_beta2_Gsub = mmSCT[np.floor(G_sub*T).astype(int),0,1]
    UB_beta2_Gsub = mmSCT[np.floor(G_sub*T).astype(int),1,1]
    if np.sum((LB_beta2_Gsub < (beta2(G_sub))) & ((beta2(G_sub)) < UB_beta2_Gsub)) == len(G_sub):
        if_cover_2_Gsub = 1
    else:
        if_cover_2_Gsub = 0

    ######## Pointiwse band beta2
    P_LB_beta2 = LB_beta2
    P_UB_beta2 = UB_beta2

    return LB_beta1, UB_beta1, LB_beta1_G, UB_beta1_G, LB_beta1_Gsub, UB_beta1_Gsub, \
        if_cover_1, if_cover_1_G, if_cover_1_Gsub, \
        LB_beta2, UB_beta2, LB_beta2_G, UB_beta2_G, LB_beta2_Gsub, UB_beta2_Gsub, \
        if_cover_2, if_cover_2_G, if_cover_2_Gsub, \
        P_LB_beta1, P_UB_beta1, P_LB_beta2, P_UB_beta2

# In[]
######### MC #########
def MC_SB(h, vY, mX, sBName):
    alpha = 0.05
    T = 200
    n = T
    htilde = 2 * (h ** (5 / 9))
    taut = np.arange(1 / T, (T + 1) / T, 1 / T)
    B = 1299
    
    if sBName == 'BW':
        f = BW_BT
    elif sBName == 'NBW':
        f = NBW_BT
    elif sBName == 'CBW':
        f = CBW_BT
    elif sBName == 'LBWB':
        f = LBW_BT

    betatilde = estimator(vY, mX, htilde, taut, taut)
    betahat = estimator(vY, mX, h, taut, taut)

    G, G_sub, len_G, len_Gsub = G_sample(h)
    betatilde_G = estimator(vY, mX, htilde, G, taut)
    betahat_G = estimator(vY, mX, h, G, taut)

    betatilde_Gsub = estimator(vY, mX, htilde, G_sub, taut)
    betahat_Gsub = estimator(vY, mX, h, G_sub, taut)

    zhat = vY - (mX @ betatilde).diagonal()
    betahat_star = np.zeros(shape=(B, 2, T))
    betahat_star_G = np.zeros(shape=(B, 2, len(G)))
    betahat_star_Gsub = np.zeros(shape=(B, 2, len(G_sub)))

    if sBName in ['SB','SWB']:
        epsilonhat,max_lag,armodel= AR(zhat)
        epsilontilde = epsilonhat  - np.mean(epsilonhat)
    # #### For Block bootstrap
    for i in range(B):
        if sBName =='SWB':
            vYstar = SW_BT(epsilonhat, max_lag, zhat, armodel, mX, betatilde)
        elif sBName == 'SB':
            vYstar = S_BT(epsilontilde, max_lag, zhat, armodel, mX, betatilde)
        elif sBName == 'LBWB':
            vYstar = LBW_BT(zhat, mX, betatilde, h)
        else:
            vYstar = f(zhat, mX, betatilde)
        betahat_star[i] = estimator(vYstar, mX, h, taut, taut)
        betahat_star_G[i] = estimator(vYstar, mX, h, G, taut)
        betahat_star_Gsub[i] = estimator(vYstar, mX, h, G_sub, taut)

    diff_beta1 = np.zeros(shape=(B, T))
    diff_beta2 = np.zeros(shape=(B, T))

    diff_beta1_G = np.zeros(shape=(B, len(G)))
    diff_beta2_G = np.zeros(shape=(B, len(G)))

    diff_beta1_Gsub = np.zeros(shape=(B, len(G_sub)))
    diff_beta2_Gsub = np.zeros(shape=(B, len(G_sub)))


    for i in range(B):
        diff_beta1[i] = (betahat_star[i] - betatilde)[0]
        diff_beta2[i] = (betahat_star[i] - betatilde)[1]

        diff_beta1_G[i] = (betahat_star_G[i] - betatilde_G)[0]
        diff_beta2_G[i] = (betahat_star_G[i] - betatilde_G)[1]

        diff_beta1_Gsub[i] = (betahat_star_Gsub[i] - betatilde_Gsub)[0]
        diff_beta2_Gsub[i] = (betahat_star_Gsub[i] - betatilde_Gsub)[1]

    ########

    optimal_alphap_1 = min_alphap(diff_beta1, taut)
    optimal_alphap_2 = min_alphap(diff_beta2, taut)

    optimal_alphap_1_G = min_alphap(diff_beta1_G, G)
    optimal_alphap_2_G = min_alphap(diff_beta2_G, G)

    optimal_alphap_1_Gsub = min_alphap(diff_beta1_Gsub, G_sub)
    optimal_alphap_2_Gsub = min_alphap(diff_beta2_Gsub, G_sub)

    ######## Simul band beta1
    LB_beta1 = betahat[0] - get_qtau(optimal_alphap_1, diff_beta1, taut)[1]
    UB_beta1 = betahat[0] - get_qtau(optimal_alphap_1, diff_beta1, taut)[0]
    if np.sum((LB_beta1 < (beta1(taut))) & ((beta1(taut)) < UB_beta1)) == T:
        if_cover_1 = 1
    else:
        if_cover_1 = 0

    LB_beta1_G = betahat_G[0] - get_qtau(optimal_alphap_1_G, diff_beta1_G, G)[1]
    UB_beta1_G = betahat_G[0] - get_qtau(optimal_alphap_1_G, diff_beta1_G, G)[0]
    LB_beta1_full_G = betahat[0] - get_qtau(optimal_alphap_1_G, diff_beta1, taut)[1]
    UB_beta1_full_G = betahat[0] - get_qtau(optimal_alphap_1_G, diff_beta1, taut)[0]
    if np.sum((LB_beta1_G < (beta1(G))) & ((beta1(G)) < UB_beta1_G)) == len(G):
        if_cover_1_G = 1
    else:
        if_cover_1_G = 0
    

    LB_beta1_Gsub = betahat_Gsub[0] - get_qtau(optimal_alphap_1_Gsub, diff_beta1_Gsub, G_sub)[1]
    UB_beta1_Gsub = betahat_Gsub[0] - get_qtau(optimal_alphap_1_Gsub, diff_beta1_Gsub, G_sub)[0]
    LB_beta1_full_Gsub = betahat[0] - get_qtau(optimal_alphap_1_Gsub, diff_beta1, taut)[1]
    UB_beta1_full_Gsub = betahat[0] - get_qtau(optimal_alphap_1_Gsub, diff_beta1, taut)[0]
    if np.sum((LB_beta1_Gsub < (beta1(G_sub))) & ((beta1(G_sub)) < UB_beta1_Gsub)) == len(G_sub):
        if_cover_1_Gsub = 1
    else:
        if_cover_1_Gsub = 0

    ######## Pointiwse band beta1
    P_LB_beta1 = betahat[0] - get_qtau(0.05, diff_beta1, taut)[1]
    P_UB_beta1 = betahat[0] - get_qtau(0.05, diff_beta1, taut)[0]

    ######
    ###### Simul band beta2
    LB_beta2 = betahat[1] - get_qtau(optimal_alphap_2, diff_beta2, taut)[1]
    UB_beta2 = betahat[1] - get_qtau(optimal_alphap_2, diff_beta2, taut)[0]
    if np.sum((LB_beta2 < (beta2(taut))) & ((beta2(taut)) < UB_beta2)) == T:
        if_cover_2 = 1
    else:
        if_cover_2 = 0

    LB_beta2_G = betahat_G[1] - get_qtau(optimal_alphap_2_G, diff_beta2_G, G)[1]
    UB_beta2_G = betahat_G[1] - get_qtau(optimal_alphap_2_G, diff_beta2_G, G)[0]
    LB_beta2_full_G = betahat[1] - get_qtau(optimal_alphap_2_G, diff_beta2, taut)[1]
    UB_beta2_full_G = betahat[1] - get_qtau(optimal_alphap_2_G, diff_beta2, taut)[0]
    if np.sum((LB_beta2_G < (beta2(G))) & ((beta2(G)) < UB_beta2_G)) == len(G):
        if_cover_2_G = 1
    else:
        if_cover_2_G = 0

    LB_beta2_Gsub = betahat_Gsub[1] - get_qtau(optimal_alphap_2_Gsub, diff_beta2_Gsub, G_sub)[1]
    UB_beta2_Gsub = betahat_Gsub[1] - get_qtau(optimal_alphap_2_Gsub, diff_beta2_Gsub, G_sub)[0]
    LB_beta2_full_Gsub = betahat[1] - get_qtau(optimal_alphap_2_Gsub, diff_beta2, taut)[1]
    UB_beta2_full_Gsub = betahat[1] - get_qtau(optimal_alphap_2_Gsub, diff_beta2, taut)[0]
    if np.sum((LB_beta2_Gsub < (beta2(G_sub))) & ((beta2(G_sub)) < UB_beta2_Gsub)) == len(G_sub):
        if_cover_2_Gsub = 1
    else:
        if_cover_2_Gsub = 0

    ######## Pointiwse band beta2
    P_LB_beta2 = betahat[1] - get_qtau(0.05, diff_beta2, taut)[1]
    P_UB_beta2 = betahat[1] - get_qtau(0.05, diff_beta2, taut)[0]

    return LB_beta1, UB_beta1, LB_beta1_G, UB_beta1_G, LB_beta1_Gsub, UB_beta1_Gsub, \
        if_cover_1, if_cover_1_G, if_cover_1_Gsub, \
        LB_beta2, UB_beta2, LB_beta2_G, UB_beta2_G, LB_beta2_Gsub, UB_beta2_Gsub, \
        if_cover_2, if_cover_2_G, if_cover_2_Gsub, \
        P_LB_beta1, P_UB_beta1, P_LB_beta2, P_UB_beta2,\
        LB_beta1_full_G, UB_beta1_full_G, LB_beta1_full_Gsub, UB_beta1_full_Gsub,\
        LB_beta2_full_G, UB_beta2_full_G, LB_beta2_full_Gsub, UB_beta2_full_Gsub

def multi_h_MC(i_MC, sBName):
    # report progress
    if i_MC%100 == 0:
        print("Iteration %i out of 1000\n"%i_MC)
    
    np.random.seed(i_MC)
    vxi=generatevxi()
    vY, mX = simulateData_ZW(vxi)

    np.random.seed()
    # plt.plot(vY)
    h = [0.09, 0.12, 0.15 , 0.18, 0.21, 0.24]
    len_G = [72, 84, 90, 96, 100, 100]
    len_Gsub = [36, 48, 60, 72, 82, 88]
    S_LB_beta1 = np.zeros(shape=(6, 200))
    S_LB_beta2 = np.zeros(shape=(6, 200))
    S_UB_beta1 = np.zeros(shape=(6, 200))
    S_UB_beta2 = np.zeros(shape=(6, 200))
    P_LB_beta1 = np.zeros(shape=(6, 200))
    P_UB_beta1 = np.zeros(shape=(6, 200))
    P_LB_beta2 = np.zeros(shape=(6, 200))
    P_UB_beta2 = np.zeros(shape=(6, 200))
    
    LB_beta1_full_G = np.zeros((6,200))
    UB_beta1_full_G = np.zeros((6,200))
    LB_beta1_full_Gsub = np.zeros((6,200))
    UB_beta1_full_Gsub = np.zeros((6,200))
    LB_beta2_full_G = np.zeros((6,200))
    UB_beta2_full_G = np.zeros((6,200))
    LB_beta2_full_Gsub = np.zeros((6,200))
    UB_beta2_full_Gsub = np.zeros((6,200))

    S_LB_beta1_G = np.zeros(shape=(6, 108))
    S_LB_beta2_G = np.zeros(shape=(6, 108))
    S_UB_beta1_G = np.zeros(shape=(6, 108))
    S_UB_beta2_G = np.zeros(shape=(6, 108))

    S_LB_beta1_Gsub = np.zeros(shape=(6, 96))
    S_LB_beta2_Gsub = np.zeros(shape=(6, 96))
    S_UB_beta1_Gsub = np.zeros(shape=(6, 96))
    S_UB_beta2_Gsub = np.zeros(shape=(6, 96))
    S_if_cover_1 = np.zeros(shape=(6, 1))
    S_if_cover_2 = np.zeros(shape=(6, 1))
    S_if_cover_1_G = np.zeros(shape=(6, 1))
    S_if_cover_2_G = np.zeros(shape=(6, 1))
    S_if_cover_1_Gsub = np.zeros(shape=(6, 1))
    S_if_cover_2_Gsub = np.zeros(shape=(6, 1))
    
    if sBName == 'ZW':
        f = MC_ZW
    else:
        f = MC_SB

    for i in range(6):
        S_LB_beta1[i], S_UB_beta1[i], S_LB_beta1_G[i][:len_G[i]], S_UB_beta1_G[i][:len_G[i]], S_LB_beta1_Gsub[i][
                                                                                              :len_Gsub[i]], \
        S_UB_beta1_Gsub[i][:len_Gsub[i]], \
            S_if_cover_1[i], S_if_cover_1_G[i], S_if_cover_1_Gsub[i], \
            S_LB_beta2[i], S_UB_beta2[i], S_LB_beta2_G[i][:len_G[i]], S_UB_beta2_G[i][:len_G[i]], S_LB_beta2_Gsub[i][
                                                                                                  :len_Gsub[i]], \
        S_UB_beta2_Gsub[i][:len_Gsub[i]], \
            S_if_cover_2[i], S_if_cover_2_G[i], S_if_cover_2_Gsub[i], \
            P_LB_beta1[i], P_UB_beta1[i], P_LB_beta2[i], P_UB_beta2[i],\
                LB_beta1_full_G[i], UB_beta1_full_G[i], LB_beta1_full_Gsub[i], UB_beta1_full_Gsub[i],\
                LB_beta2_full_G[i], UB_beta2_full_G[i], LB_beta2_full_Gsub[i], UB_beta2_full_Gsub[i] = f(h[i], vY, mX, sBName)

    return S_LB_beta1, S_UB_beta1, S_LB_beta1_G, S_UB_beta1_G, S_LB_beta1_Gsub, S_UB_beta1_Gsub, \
        S_if_cover_1, S_if_cover_1_G, S_if_cover_1_Gsub, \
        S_LB_beta2, S_UB_beta2, S_LB_beta2_G, S_UB_beta2_G, S_LB_beta2_Gsub, S_UB_beta2_Gsub, \
        S_if_cover_2, S_if_cover_2_G, S_if_cover_2_Gsub, \
        P_LB_beta1, P_UB_beta1, P_LB_beta2, P_UB_beta2,\
        LB_beta1_full_G, UB_beta1_full_G, LB_beta1_full_Gsub, UB_beta1_full_Gsub,\
        LB_beta2_full_G, UB_beta2_full_G, LB_beta2_full_Gsub, UB_beta2_full_Gsub


def subset_U(h, i):
    vUu = np.zeros(math.floor(200 * h))
    for j in range(math.floor(200 * h)):
        vUu[j] = i / 5 - h + j / 100
    return vUu

def G_sample(h):
    G = np.concatenate((subset_U(h, 1), subset_U(h, 2), subset_U(h, 3), subset_U(h, 4)))
    G_sub = np.concatenate((subset_U(h, 1), subset_U(h, 4)))

    G, G_sub = np.unique(G.round(4)), np.unique(G_sub.round(4))
    G = G[(G*T >=0) & (G*T < 200)]
    G_sub = G_sub[(G_sub*T >=0) & (G_sub*T < 200)]
    
    len_G, len_Gsub = len(G), len(G_sub)
    
    return G, G_sub, len_G, len_Gsub

def Simu_Band_Cov(results, times):
    a = []
    b = []
    c = []
    d = []
    e = []
    f = []
    aa = []
    bb = []
    cc = []
    dd = []
    ee = []
    ff = []


    for i in range(times):
        a.append(results[i][6][0])
        b.append(results[i][15][0])
        c.append(results[i][6][1])
        d.append(results[i][15][1])
        e.append(results[i][6][2])
        f.append(results[i][15][2])

        aa.append(results[i][6][3])
        bb.append(results[i][15][3])
        cc.append(results[i][6][4])
        dd.append(results[i][15][4])
        ee.append(results[i][6][5])
        ff.append(results[i][15][5])

    # print("h1 beta1:", np.sum(a) / times, "h2 beta1:", np.sum(c) / times, "h3 beta1:", np.sum(e) / times,
    #       "h1 beta2:", np.sum(b) / times, "h2 beta2:", np.sum(d) / times, "h3 beta2:", np.sum(f) / times)
    return (np.sum(a) / times, np.sum(c) / times,  np.sum(e) / times, np.sum(b) / times, np.sum(d) / times, np.sum(f) / times,
            np.sum(aa) / times, np.sum(cc) / times, np.sum(ee) / times, np.sum(bb) / times, np.sum(dd) / times, np.sum(ff) / times)

def Simu_Band_Cov_G(results, times):
    a = []
    b = []
    c = []
    d = []
    e = []
    f = []
    aa = []
    bb = []
    cc = []
    dd = []
    ee = []
    ff = []

    for i in range(times):
        a.append(results[i][7][0])
        b.append(results[i][16][0])
        c.append(results[i][7][1])
        d.append(results[i][16][1])
        e.append(results[i][7][2])
        f.append(results[i][16][2])

        aa.append(results[i][7][3])
        bb.append(results[i][16][3])
        cc.append(results[i][7][4])
        dd.append(results[i][16][4])
        ee.append(results[i][7][5])
        ff.append(results[i][16][5])

    # print("h1 beta1:", np.sum(a) / times, "h2 beta1:", np.sum(c) / times, "h3 beta1:", np.sum(e) / times,
    #       "h1 beta2:", np.sum(b) / times, "h2 beta2:", np.sum(d) / times, "h3 beta2:", np.sum(f) / times)
    return np.sum(a) / times, np.sum(c) / times, np.sum(e) / times, np.sum(b) / times, np.sum(d) / times, np.sum(
        f) / times,  np.sum(aa) / times, np.sum(cc) / times, np.sum(ee) / times, np.sum(bb) / times, np.sum(dd) / times, np.sum(ff) / times

def Simu_Band_Cov_Gsub(results, times):
    a = []
    b = []
    c = []
    d = []
    e = []
    f = []
    aa = []
    bb = []
    cc = []
    dd = []
    ee = []
    ff = []

    for i in range(times):
        a.append(results[i][8][0])
        b.append(results[i][17][0])
        c.append(results[i][8][1])
        d.append(results[i][17][1])
        e.append(results[i][8][2])
        f.append(results[i][17][2])

        aa.append(results[i][8][3])
        bb.append(results[i][17][3])
        cc.append(results[i][8][4])
        dd.append(results[i][17][4])
        ee.append(results[i][8][5])
        ff.append(results[i][17][5])

    # print("h1 beta1:", np.sum(a) / times, "h2 beta1:", np.sum(c) / times, "h3 beta1:", np.sum(e) / times,
    #       "h1 beta2:", np.sum(b) / times, "h2 beta2:", np.sum(d) / times, "h3 beta2:", np.sum(f) / times)
    return np.sum(a) / times, np.sum(c) / times, np.sum(e) / times, np.sum(b) / times, np.sum(d) / times, np.sum(
        f) / times,  np.sum(aa) / times, np.sum(cc) / times, np.sum(ee) / times, np.sum(bb) / times, np.sum(dd) / times, np.sum(ff) / times

def PW_Band_Cov(results, times):
    a = []
    b = []
    c = []
    d = []
    e = []
    f = []
    aa = []
    bb = []
    cc = []
    dd = []
    ee = []
    ff = []

    for i in range(times):
        a.append(np.sum((results[i][18][0] < (beta1(taut))) & ((beta1(taut)) < results[i][19][0])) / T)
        b.append(np.sum((results[i][20][0] < (beta2(taut))) & ((beta2(taut)) < results[i][21][0])) / T)
        c.append(np.sum((results[i][18][1] < (beta1(taut))) & ((beta1(taut)) < results[i][19][1])) / T)
        d.append(np.sum((results[i][20][1] < (beta2(taut))) & ((beta2(taut)) < results[i][21][1])) / T)
        e.append(np.sum((results[i][18][2] < (beta1(taut))) & ((beta1(taut)) < results[i][19][2])) / T)
        f.append(np.sum((results[i][20][2] < (beta2(taut))) & ((beta2(taut)) < results[i][21][2])) / T)
        aa.append(np.sum((results[i][18][3] < (beta1(taut))) & ((beta1(taut)) < results[i][19][3])) / T)
        bb.append(np.sum((results[i][20][3] < (beta2(taut))) & ((beta2(taut)) < results[i][21][3])) / T)
        cc.append(np.sum((results[i][18][4] < (beta1(taut))) & ((beta1(taut)) < results[i][19][4])) / T)
        dd.append(np.sum((results[i][20][4] < (beta2(taut))) & ((beta2(taut)) < results[i][21][4])) / T)
        ee.append(np.sum((results[i][18][5] < (beta1(taut))) & ((beta1(taut)) < results[i][19][5])) / T)
        ff.append(np.sum((results[i][20][5] < (beta2(taut))) & ((beta2(taut)) < results[i][21][5])) / T)


    return (np.average(a), np.average(c),  np.average(e), np.average(b), np.average(d), np.average(f),
            np.average(aa), np.average(cc),  np.average(ee), np.average(bb), np.average(dd), np.average(ff))

def Emp_len(results, times):
    FS_len_1 = np.zeros(shape=(6, times))
    FS_len_2 = np.zeros(shape=(6, times))
    PW_len_1 = np.zeros(shape=(6, times))
    PW_len_2 = np.zeros(shape=(6, times))

    G_len_1 = np.zeros(shape=(6, times))
    G_len_2 = np.zeros(shape=(6, times))
    Gsub_len_1 = np.zeros(shape=(6, times))
    Gsub_len_2 = np.zeros(shape=(6, times))

    for i in range(times):
        FS_len_1[:, i] = np.median(results[i][1] - results[i][0], axis=1)
        FS_len_2[:, i] = np.median(results[i][10] - results[i][9], axis=1)
        PW_len_1[:, i] = np.median(results[i][19] - results[i][18], axis=1)
        PW_len_2[:, i] = np.median(results[i][21] - results[i][20], axis=1)

        G_len_1[:, i][0] = np.median((results[i][23] - results[i][22])[0])
        G_len_1[:, i][1] = np.median((results[i][23] - results[i][22])[1])
        G_len_1[:, i][2] = np.median((results[i][23] - results[i][22])[2])
        G_len_1[:, i][3] = np.median((results[i][23] - results[i][22])[3])
        G_len_1[:, i][4] = np.median((results[i][23] - results[i][22])[4])
        G_len_1[:, i][5] = np.median((results[i][23] - results[i][22])[5])

        G_len_2[:, i][0] = np.median((results[i][27] - results[i][26])[0])
        G_len_2[:, i][1] = np.median((results[i][27] - results[i][26])[1])
        G_len_2[:, i][2] = np.median((results[i][27] - results[i][26])[2])
        G_len_2[:, i][3] = np.median((results[i][27] - results[i][26])[3])
        G_len_2[:, i][4] = np.median((results[i][27] - results[i][26])[4])
        G_len_2[:, i][5] = np.median((results[i][27] - results[i][26])[5])

        Gsub_len_1[:, i][0] = np.median((results[i][25] - results[i][24])[0])
        Gsub_len_1[:, i][1] = np.median((results[i][25] - results[i][24])[1])
        Gsub_len_1[:, i][2] = np.median((results[i][25] - results[i][24])[2])
        Gsub_len_1[:, i][3] = np.median((results[i][25] - results[i][24])[3])
        Gsub_len_1[:, i][4] = np.median((results[i][25] - results[i][24])[4])
        Gsub_len_1[:, i][5] = np.median((results[i][25] - results[i][24])[5])

        Gsub_len_2[:, i][0] = np.median((results[i][29] - results[i][28])[0])
        Gsub_len_2[:, i][1] = np.median((results[i][29] - results[i][28])[1])
        Gsub_len_2[:, i][2] = np.median((results[i][29] - results[i][28])[2])
        Gsub_len_2[:, i][3] = np.median((results[i][29] - results[i][28])[3])
        Gsub_len_2[:, i][4] = np.median((results[i][29] - results[i][28])[4])
        Gsub_len_2[:, i][5] = np.median((results[i][29] - results[i][28])[5])

    # print("FS beta1:", np.average(FS_len_1, axis=1), "FS beta2:", np.average(FS_len_2, axis=1),
    #       "G beta1:", np.average(G_len_1, axis=1), "G beta2:", np.average(G_len_2, axis=1),
    #       "Gsub beta1:", np.average(Gsub_len_1, axis=1), "Gsub beta2:", np.average(Gsub_len_2, axis=1),
    #       "PW beta1:", np.average(PW_len_1, axis=1), "PW beta2:", np.average(PW_len_2, axis=1))
    return  np.average(FS_len_1, axis=1), np.average(FS_len_2, axis=1), np.average(G_len_1, axis=1), np.average(G_len_2, axis=1),np.average(Gsub_len_1, axis=1), np.average(Gsub_len_2, axis=1),\
    np.average(PW_len_1, axis=1), np.average(PW_len_2, axis=1)

def Emp_len_garch(results, times):
    FS_len_1 = np.zeros(shape=(6, times))
    FS_len_2 = np.zeros(shape=(6, times))
    PW_len_1 = np.zeros(shape=(6, times))
    PW_len_2 = np.zeros(shape=(6, times))

    G_len_1 = np.zeros(shape=(6, times))
    G_len_2 = np.zeros(shape=(6, times))
    Gsub_len_1 = np.zeros(shape=(6, times))
    Gsub_len_2 = np.zeros(shape=(6, times))

    for i in range(times):
        FS_len_1[:, i] = np.median(results[i][1] - results[i][0], axis=1)
        FS_len_2[:, i] = np.median(results[i][10] - results[i][9], axis=1)
        PW_len_1[:, i] = np.median(results[i][19] - results[i][18], axis=1)
        PW_len_2[:, i] = np.median(results[i][21] - results[i][20], axis=1)

        G_len_1[:, i][0] = np.median((results[i][23] - results[i][22])[0])
        G_len_1[:, i][1] = np.median((results[i][23] - results[i][22])[1])
        G_len_1[:, i][2] = np.median((results[i][23] - results[i][22])[2])
        G_len_1[:, i][3] = np.median((results[i][23] - results[i][22])[3])
        G_len_1[:, i][4] = np.median((results[i][23] - results[i][22])[4])
        G_len_1[:, i][5] = np.median((results[i][23] - results[i][22])[5])

        G_len_2[:, i][0] = np.median((results[i][27] - results[i][26])[0])
        G_len_2[:, i][1] = np.median((results[i][27] - results[i][26])[1])
        G_len_2[:, i][2] = np.median((results[i][27] - results[i][26])[2])
        G_len_2[:, i][3] = np.median((results[i][27] - results[i][26])[3])
        G_len_2[:, i][4] = np.median((results[i][27] - results[i][26])[4])
        G_len_2[:, i][5] = np.median((results[i][27] - results[i][26])[5])

        Gsub_len_1[:, i][0] = np.median((results[i][25] - results[i][24])[0])
        Gsub_len_1[:, i][1] = np.median((results[i][25] - results[i][24])[1])
        Gsub_len_1[:, i][2] = np.median((results[i][25] - results[i][24])[2])
        Gsub_len_1[:, i][3] = np.median((results[i][25] - results[i][24])[3])
        Gsub_len_1[:, i][4] = np.median((results[i][25] - results[i][24])[4])
        Gsub_len_1[:, i][5] = np.median((results[i][25] - results[i][24])[5])

        Gsub_len_2[:, i][0] = np.median((results[i][29] - results[i][28])[0])
        Gsub_len_2[:, i][1] = np.median((results[i][29] - results[i][28])[1])
        Gsub_len_2[:, i][2] = np.median((results[i][29] - results[i][28])[2])
        Gsub_len_2[:, i][3] = np.median((results[i][29] - results[i][28])[3])
        Gsub_len_2[:, i][4] = np.median((results[i][29] - results[i][28])[4])
        Gsub_len_2[:, i][5] = np.median((results[i][29] - results[i][28])[5])

    # print("FS beta1:", np.median(FS_len_1, axis=1), "FS beta2:", np.median(FS_len_2, axis=1),
    #       "G beta1:", np.median(G_len_1, axis=1), "G beta2:", np.median(G_len_2, axis=1),
    #       "Gsub beta1:", np.median(Gsub_len_1, axis=1), "Gsub beta2:", np.median(Gsub_len_2, axis=1),
    #       "PW beta1:", np.median(PW_len_1, axis=1), "PW beta2:", np.median(PW_len_2, axis=1))
    return np.median(FS_len_1, axis=1), np.median(FS_len_2, axis=1), np.median(G_len_1, axis=1), np.median(G_len_2,axis=1),np.median(Gsub_len_1, axis=1),\
        np.median( Gsub_len_2, axis=1), np.median(PW_len_1, axis=1), np.median(PW_len_2, axis=1)


if __name__ == '__main__':
    iNsim = 1000
    i_MC_list = np.arange(1, iNsim+1)
    
    sBNames = ['LBWB','NBW','CBW','SB', 'SWB']
    for sBName in sBNames:
        print(sBName)
        
        # Use the Parallel function to apply the process_data function to the data in parallel
        results = Parallel(n_jobs = 1, backend='multiprocessing', verbose=10, batch_size=int(iNsim/1))(delayed(multi_h_MC)(i_MC, sBName) for i_MC in i_MC_list)
        # Print the results

        re1 = Simu_Band_Cov(results, iNsim)
        filename = f'FULL_{sBName}_NL1_11.txt'
        np.savetxt(filename, re1, delimiter='', fmt='%1.4f')

        re2 = Simu_Band_Cov_G(results, iNsim)
        filename = f'G_{sBName}_NL1_11.txt'
        np.savetxt(filename, re2, delimiter='', fmt='%1.4f')

        re3 = Simu_Band_Cov_Gsub(results, iNsim)
        filename = f'Gsub_{sBName}_NL1_11.txt'
        np.savetxt(filename, re3, delimiter='', fmt='%1.4f')

        re4 = PW_Band_Cov(results, iNsim)
        filename = f'P_{sBName}_NL1_11.txt'
        np.savetxt(filename, re4, delimiter='', fmt='%1.4f')

        re5 = Emp_len(results, iNsim)
        filename = f'Len_{sBName}_NL1_11.txt'
        np.savetxt(filename, re5, delimiter='', fmt='%1.4f')
