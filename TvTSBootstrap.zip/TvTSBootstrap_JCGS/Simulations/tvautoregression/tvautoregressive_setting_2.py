# Copyright: Yicong Lin, Mingxuan Song, Bernhard van der Sluis
#
# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

# ==================================================#
# Researchers are free to use the code.
# Please cite the following papers:
# 1. Yicong Lin, Mingxuan Song and Bernhard van der Sluis (2024). Bootstrap inference for linear time-varying coefficient models in locally stationary time series.
# 2. Marina Friedrich and Yicong Lin (2024). Sieve bootstrap inference for linear time-varying coefficient models. Journal of Econometrics.

# Purpose: Simulation for time-varying autoregressive model, setting 2, data size n = 200. See Appendix C.4.2.


import os
os.environ['MKL_NUM_THREADS']='1' 
os.environ['OMP_NUM_THREADS']='1'
import numpy as np
# import matplotlib.pyplot as plt
from statsmodels.tsa.ar_model import ar_select_order
from joblib import Parallel, delayed
from statsmodels.tsa.ar_model import AutoReg
# import math
import warnings
warnings.filterwarnings('ignore')
# import sys

alpha = 0.05
T = 200
n = T
dSqrt2 = np.sqrt(2)
d2Sqrt2 = 2*dSqrt2
taut = np.arange(1,T+1,1)/T

# In[]
def beta(tau):
    return 0.5*np.exp(tau-0.5)

######### Simulation Data #########
def simulateData():
    # initialize error process
    vC0 = 2.4 + 0.02*np.cos(np.pi*taut)#2*np.exp(0.5*taut - 0.5)
    vC1 = 0.4+0.1*np.cos(np.pi*taut)#0.4 + 0.05*np.cos(taut)
    vD1 = 0.5-0.1*np.cos(np.pi*taut)#0.4 - 0.1*np.cos(taut)
    vRho = 0.1*np.sin(np.pi*taut)
    
    vBeta = beta(taut)
    vEpsilon = np.random.normal(0,1,T+1)
    vU = np.zeros(T+1)
    vU[0] = vEpsilon[0]
    vH = np.ones(T+1)
    
    vY = np.zeros(T+1)
    vY[0] = np.random.normal(0,1,1)
    for t in range(1,T+1):
        vH[t] = vC0[t-1] + vC1[t-1]*(vU[t-1]**2) + vD1[t-1]*vH[t-1]
        vU[t] = vRho[t-1]*vU[t-1] + np.sqrt(vH[t])*vEpsilon[t]
        vY[t] = vBeta[t-1] * vY[t-1] + vU[t]
    
    mX = np.zeros((T,1))
    mX[:,0] = vY[:-1]
    vY = vY[1:]
    
    return vY, mX

# In[]
######### Estimation #########
def K(u):
    # return (1/np.sqrt(2*np.pi))*np.exp(-0.5*u**2)
    return np.where(np.abs(u) <= 1, 0.75 * (1 - u ** 2), 0)

def Sn(k, tau, mX, h, times):
    u = (times[None, :] - tau) / h
    K_u = K(u)

    return np.sum((mX[:, None, :] * mX[:, :, None]) * np.reshape(((times[None, :] - tau) ** k) * K_u,
                                                                 newshape=(len(times), 1, 1)), axis=0) / (h)

def Tn(k, tau, mX, vY, h, times):
    u = (times[None, :] - tau) / h
    K_u = K(u)

    return np.sum(
        mX[:, :, None] * np.reshape((times[None, :] - tau) ** k * K_u, newshape=(len(times), 1, 1)) * vY.reshape(T, 1,
                                                                                                                 1),
        axis=0) / (h)

def get_mS(tau, mX, h, times):
    mS = np.zeros(shape=(2, 2))
    Sn0 = Sn(0, tau, mX, h, times)
    Sn1 = Sn(1, tau, mX, h, times)
    Sn2 = Sn(2, tau, mX, h, times)
    size = Sn0.shape[0]
    mS[:size, :size] = Sn0
    mS[:size, size:] = Sn1
    mS[size:, :size] = Sn1.T
    mS[size:, size:] = Sn2
    return mS

def get_mT(tau, mX, vY, h, times):
    mT = np.zeros(shape=(2, 1))
    Tn0 = Tn(0, tau, mX, vY, h, times)
    Tn1 = Tn(1, tau, mX, vY, h, times)
    size = Tn0.shape[0]

    mT[:size, 0] = Tn0[:, 0]
    mT[size:, 0] = Tn1[:, 0]

    return mT

def estimator(vY, mX, h, tau, times):
    betahat = np.zeros(shape=(1, len(tau)))
    for i in range(len(tau)):
        mS, mT = get_mS(tau[i], mX, h, times), get_mT(tau[i], mX, vY, h, times)
        mul = np.linalg.inv(mS) @ mT
        betahat[:, i][0] = mul[0]
        # betahat[:, i][1] = mul[1]

    return betahat

######### Bandwidth Selection #########
def bandwth_selection(vY, mX, betahat):
    vYfit = betahat[0] * mX[:, 0] + betahat[1] * mX[:, 1]
    Q_h = (((vY.reshape(1, T)) @ vY) ** (-1)) * (vYfit.reshape(T, 1) @ vY.reshape(1, T))
    sigma_hat2 = np.sum((vYfit - vY) ** 2) / n
    AIC = np.log(sigma_hat2) + (2 * (np.matrix.trace(Q_h) + 1)) / (n - np.matrix.trace(Q_h) - 2)
    # print(sigma_hat2)
    GCV = sigma_hat2 / (1 - np.matrix.trace(Q_h) / n) ** 2
    return AIC, GCV


######### Bootstrap Setup #########
def AR(zhat):
    maxp = 10 * np.log10(200)
    arm_selection = ar_select_order(zhat, ic='aic', trend='n', maxlag=int(maxp))

    if arm_selection.ar_lags is None:  ######
        armodel = AutoReg(zhat, trend='n', lags=0).fit()
        max_lag = 0  ## to avoid the nonetype error
        epsilonhat = zhat
        #epsilontilde = epsilonhat #- np.mean(epsilonhat)
    else:
        armodel = arm_selection.model.fit()
        max_lag = max(arm_selection.ar_lags)
        epsilonhat = armodel.resid
        #epsilontilde = epsilonhat #- np.mean(epsilonhat)

    return epsilonhat, max_lag, armodel
# In[]
######### Sieve Bootstrap #########
def S_BT(epsilontilde, max_lag, zhat, armodel, mX, betatilde):
    epsilonstar = np.random.choice(epsilontilde, T - max_lag + 50)
    if max_lag == 0:
        zstar = epsilonstar[50:]
        zstar_array = zstar

    # elif max_lag ==1:
    #
    #     zstar_array = np.zeros(T)
    #
    #     for j in range(T - max_lag):
    #         zstar_array[j + max_lag] = zstar_array[j + max_lag-1]*armodel.params[0] +epsilonstar[20+j]
    else:

        max_lag = np.arange(1, max_lag + 1)

        zstar_array = get_Zstar_AR(max_lag, armodel, 200, epsilonstar)

    vYstar = (mX @ betatilde + zstar_array).diagonal()

    return vYstar

######### Sieve Wild Bootstrap #########
def SW_BT(epsilontilde, max_lag, zhat, armodel, mX, betatilde):
    epsilonstar = epsilontilde * np.random.normal(0, 1, T - max_lag)
    epsilonstar = np.random.choice(epsilonstar, T - max_lag + 50)
    if max_lag == 0:
        zstar = epsilonstar[50:]
        zstar_array = zstar

    # elif max_lag ==1:
    #
    #     zstar_array = np.zeros(T)
    #
    #     for j in range(T - max_lag):
    #         zstar_array[j + max_lag] = zstar_array[j + max_lag-1]*armodel.params[0] +epsilonstar[20+j]
    else:

        max_lag = np.arange(1, max_lag + 1)

        zstar_array = get_Zstar_AR(max_lag, armodel, 200, epsilonstar)

    vYstar = (mX @ betatilde + zstar_array).diagonal()

    return vYstar

def get_Zstar_AR(max_lags, armodel, T, epsilonstar):
    # Initialize the AR process with the known initial values
    zstar = np.zeros(len(max_lags))

    # Add the AR component for each lag value and coefficient
    for i in range(len(max_lags), T):
        ar_component = 0
        for j, lag in enumerate(max_lags):
            lagged_data = zstar[i - lag]
            ar_component += armodel.params[j] * lagged_data

        ar_component += epsilonstar[i + 20 - len(max_lags)]
        # print(epsilonstar[i+20-len(max_lags)])
        zstar = np.append(zstar, ar_component)
    # print(armodel.params,max_lag,zstar)
    return zstar

######### Moving Block Bootstrap #########
def B_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = 200 - l + 1
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        overlapping_blocks[i] = np.array(zhat[i:i + l]).reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=int(200 / l))
    overlapping_blocks_star = overlapping_blocks[random_choice]
    zstar = overlapping_blocks_star.reshape(200, 1)

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Local Moving Block Wild Bootstrap #########
def LBW_BT(zhat, mX, betatilde, h):
    l = int(4.5 * (T*h) ** (1 / 4))

    number_blocks = T - l + 1
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        overlapping_blocks[i] = np.array(zhat[i:i + l]).reshape(l, 1)

    zstar = np.zeros(shape=(l*int(np.ceil(T/l)), 1))
    for tau in range(0, T, l):
        # local_number_blocks = l if tau in [0, T - l] else 2 * l
        local_number_blocks = np.shape(overlapping_blocks[max(tau - l, 0):tau + l])[0]
        random_choice = np.random.choice(np.arange(0, local_number_blocks), 1)
        vWild = np.repeat(np.random.normal(0, 1, 1), l)
        overlapping_blocks_star = (overlapping_blocks[max(tau - l, 0):tau + l])[random_choice]
        zstar[tau:tau + l] = overlapping_blocks_star.reshape(l, 1) * vWild.reshape(l, 1)  ## wild part

    zstar = zstar[:T]

    vYstar = (mX @ betatilde + zstar).diagonal()
    

    return vYstar


def centerBlocks(mBlocks):
    vColMeans = np.mean(mBlocks, axis=0)
    print(vColMeans.shape)
    mBlocks_centered = np.zeros((mBlocks.shape[0], mBlocks.shape[1],1))
    for col in range(mBlocks.shape[1]):
        mBlocks_centered[:,col,0] = mBlocks[:,col,0] - vColMeans[col,0]
    return mBlocks_centered

######### Centered Moving Block Bootstrap #########
def BC_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = 200 - l + 1
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        overlapping_blocks[i] = np.array(zhat[i:i + l]).reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=int(200 / l))
    overlapping_blocks_star = overlapping_blocks[random_choice]
    overlapping_blocks_star = centerBlocks(overlapping_blocks_star) # center blocks by column
    zstar = overlapping_blocks_star.reshape(200, 1)

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Non-overlapping Block Bootstrap #########
def NB_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = int(200/l)
    non_overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        non_overlapping_blocks[i] = np.array(zhat[(i)*10:(i+1)*10]).reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=number_blocks)
    non_overlapping_blocks_star = non_overlapping_blocks[random_choice]
    zstar = non_overlapping_blocks_star.reshape(200, 1)

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Centered Non-overlapping Block Bootstrap #########
def NBC_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = int(200/l)
    non_overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        non_overlapping_blocks[i] = np.array(zhat[(i)*10:(i+1)*10]).reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=number_blocks)
    non_overlapping_blocks_star = non_overlapping_blocks[random_choice]
    non_overlapping_blocks_star = centerBlocks(non_overlapping_blocks_star) # center blocks by column
    zstar = non_overlapping_blocks_star.reshape(200, 1)

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar


######### Circular Block Bootstrap #########
def CB_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = 200
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    extended_zhat = np.concatenate((zhat, zhat[:l - 1]))

    for i in range(number_blocks):
        start_idx = i % len(zhat)
        end_idx = start_idx + l

        block = extended_zhat[start_idx:end_idx]
        overlapping_blocks[i] = block.reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=int(200 / l))
    overlapping_blocks_star = overlapping_blocks[random_choice]
    zstar = overlapping_blocks_star.reshape(200, 1)

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Centered Circular Block Bootstrap #########
def CBC_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = 200
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    extended_zhat = np.concatenate((zhat, zhat[:l - 1]))

    for i in range(number_blocks):
        start_idx = i % len(zhat)
        end_idx = start_idx + l

        block = extended_zhat[start_idx:end_idx]
        overlapping_blocks[i] = block.reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=int(200 / l))
    overlapping_blocks_star = overlapping_blocks[random_choice]
    overlapping_blocks_star = centerBlocks(overlapping_blocks_star) # center blocks by column
    zstar = overlapping_blocks_star.reshape(200, 1)

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Moving Block Wild Bootstrap #########
def BW_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = 200 - l + 1
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        overlapping_blocks[i] = np.array(zhat[i:i + l]).reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=int(200 / l))
    vWild = np.repeat(np.random.normal(0, 1, 20), 10)
    overlapping_blocks_star = overlapping_blocks[random_choice]
    zstar = overlapping_blocks_star.reshape(200, 1)*vWild.reshape(200,1)## wild part

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Circular Block Wild Bootstrap #########
def CBW_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = 200
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    extended_zhat = np.concatenate((zhat, zhat[:l - 1]))

    for i in range(number_blocks):
        start_idx = i % len(zhat)
        end_idx = start_idx + l

        block = extended_zhat[start_idx:end_idx]
        overlapping_blocks[i] = block.reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=int(200 / l))
    vWild = np.repeat(np.random.normal(0, 1, 20), 10)
    overlapping_blocks_star = overlapping_blocks[random_choice]
    zstar = overlapping_blocks_star.reshape(200, 1)*vWild.reshape(200,1)## wild part

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Non-overlapping Block Wild Bootstrap #########
def NBW_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = int(200/l)
    non_overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        non_overlapping_blocks[i] = np.array(zhat[(i)*10:(i+1)*10]).reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=number_blocks)
    vWild = np.repeat(np.random.normal(0, 1, 20), 10)
    non_overlapping_blocks_star = non_overlapping_blocks[random_choice]
    zstar = non_overlapping_blocks_star.reshape(200, 1)*vWild.reshape(200,1)## wild part

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Autoregressive Bootstrap #########
def AW_BT(zhat, mX, betatilde):
    gamma = 0.2
    # v_nv_star=np.random.normal(0,np.sqrt(1-gamma**2),200)
    xi_star0 = np.random.normal(0, 1, 1)

    v_xi_star = np.zeros(T)
    v_xi_star[0] = xi_star0
    for i in range(1, T):
        v_xi_star[i] = gamma * v_xi_star[i - 1] + np.random.normal(0, np.sqrt(1 - gamma ** 2))

    zstar = v_xi_star * np.array(zhat)

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Simutaneous Bands #########
def get_qtau(alphap, diff, tau):
    qtau = np.zeros(shape=(2, len(tau)))
    for i in range(len(tau)):
        qtau[0, i] = np.quantile(diff[:, i], alphap / 2)

        qtau[1, i] = np.quantile(diff[:, i], (1 - alphap / 2))
    return qtau

def ABS_value(qtau, diff, tau):
    B = 1299
    check = np.sum((qtau[0][:, None] < diff[:, :, None]) & (diff[:, :, None] < qtau[1][:, None]), axis=1)

    return np.abs((np.sum(np.where(check == len(tau), 1, 0)) / B) - 0.95)

def min_alphap(diff, tau):
    B = 1299
    last = ABS_value(get_qtau(1 / B, diff, tau), diff, tau)
    # print(last)
    for (index, alphap) in enumerate(np.arange(2, 1299) / 1299):
        qtau = get_qtau(alphap, diff, tau)
        value = ABS_value(qtau, diff, tau)
        if value <= last:
            last = value
            if index == 63:
                return 0.05
        else:
            if index == 0:
                return (index + 1) / B
            if index == 1:
                return (index) / B
            else:
                return (index + 1) / B

# In[]
######### MC #########
def MC_SB(h, vY, mX, sBName):
    alpha = 0.05
    T = 200
    htilde = 2 * (h ** (5 / 9))
    # taut = np.arange(1 / T, (T + 1) / T, 1 / T)
    B = 1299
    
    if sBName == 'MB':
        f = B_BT
    elif sBName == 'BC':
        f = BC_BT
    elif sBName == 'BW':
        f = BW_BT
    elif sBName == 'NBC':
        f = NBC_BT
    elif sBName == 'NBW':
        f = NBW_BT
    elif sBName == 'CBC':
        f = CBC_BT
    elif sBName == 'CBW':
        f = CBW_BT
    elif sBName == 'LBWB':
        f = LBW_BT

    ftilde = estimator(vY, mX, htilde, taut, taut)
    fhat = estimator(vY, mX, h, taut, taut)
    zhat = vY - (mX @ ftilde).diagonal()
    fhat_star = np.zeros(shape=(B, 1, T))

    if sBName in ['SB','SWB']:
        epsilonhat,max_lag,armodel= AR(zhat)
        epsilontilde = epsilonhat  - np.mean(epsilonhat)
    # #### For Block bootstrap
    for i in range(B):
        if sBName =='SWB':
            vYstar = SW_BT(epsilonhat, max_lag, zhat, armodel, mX, ftilde)
        elif sBName == 'SB':
            vYstar = S_BT(epsilontilde, max_lag, zhat, armodel, mX, ftilde)
        elif sBName == 'LBWB':
            vYstar = LBW_BT(zhat, mX, ftilde, h)
        else:
            vYstar = f(zhat, mX, ftilde)
        
        fhat_star[i] = estimator(vYstar, mX, h, taut, taut)

    diff_f = np.zeros(shape=(B, T))


    for i in range(B):
        diff_f[i] = (fhat_star[i] - ftilde)[0]

    ########

    optimal_alphap = min_alphap(diff_f, taut)

    ######## Simul band beta1
    LB_f = fhat[0] - get_qtau(optimal_alphap, diff_f, taut)[1]
    UB_f = fhat[0] - get_qtau(optimal_alphap, diff_f, taut)[0]
    if np.sum((LB_f < (beta(taut))) & ((beta(taut)) < UB_f)) == T:
        if_cover = 1
    else:
        if_cover = 0


    ######## Pointiwse band beta1
    P_LB_f = fhat[0] - get_qtau(alpha, diff_f, taut)[1]
    P_UB_f = fhat[0] - get_qtau(alpha, diff_f, taut)[0]

    return LB_f, UB_f, if_cover, P_LB_f, P_UB_f

def multi_h_MC(i_MC, sBName):
    # report progress
    if i_MC%100 == 0:
        print("Iteration %i out of 1000\n"%i_MC)
    
    np.random.seed(i_MC)
    vY, mX = simulateData()

    h = [0.09, 0.12, 0.15 , 0.18, 0.21, 0.24]
    S_LB_f = np.zeros(shape=(6, 200))
    S_UB_f = np.zeros(shape=(6, 200))
    P_LB_f = np.zeros(shape=(6, 200))
    P_UB_f = np.zeros(shape=(6, 200))
    
    S_if_cover = np.zeros(shape=(6, 1))
    
    for i in range(6):
        S_LB_f[i], S_UB_f[i], S_if_cover[i], P_LB_f[i], P_UB_f[i]= MC_SB(h[i], vY, mX, sBName)

    return S_LB_f, S_UB_f, S_if_cover, P_LB_f, P_UB_f

def Simu_Band_Cov(results, times):
    a = []
    c = []
    e = []
    aa = []
    cc = []
    ee = []


    for i in range(times):
        a.append(results[i][2][0])
        c.append(results[i][2][1])
        e.append(results[i][2][2])
        aa.append(results[i][2][3])
        cc.append(results[i][2][4])
        ee.append(results[i][2][5])

    return (np.sum(a) / times, np.sum(c) / times,  np.sum(e) / times, np.sum(aa) / times, np.sum(cc) / times, np.sum(ee) / times)

def PW_Band_Cov(results, times):
    a = []
    c = []
    e = []
    aa = []
    cc = []
    ee = []

    for i in range(times):
        a.append(np.sum((results[i][3][0] < (beta(taut))) & ((beta(taut)) < results[i][4][0])) / T)
        c.append(np.sum((results[i][3][1] < (beta(taut))) & ((beta(taut)) < results[i][4][1])) / T)
        e.append(np.sum((results[i][3][2] < (beta(taut))) & ((beta(taut)) < results[i][4][2])) / T)
        aa.append(np.sum((results[i][3][3] < (beta(taut))) & ((beta(taut)) < results[i][4][3])) / T)
        cc.append(np.sum((results[i][3][4] < (beta(taut))) & ((beta(taut)) < results[i][4][4])) / T)
        ee.append(np.sum((results[i][3][5] < (beta(taut))) & ((beta(taut)) < results[i][4][5])) / T)


    return (np.average(a), np.average(c),  np.average(e), np.average(aa), np.average(cc),  np.average(ee))

def Emp_len(results, times):
    FS_len_1 = np.zeros(shape=(6, times))
    PW_len_1 = np.zeros(shape=(6, times))

    for i in range(times):
        FS_len_1[:, i] = np.median(results[i][1] - results[i][0], axis=1)
        PW_len_1[:, i] = np.median(results[i][4] - results[i][3], axis=1)

    return (np.average(FS_len_1, axis=1), np.average(PW_len_1, axis=1))

if __name__ == '__main__':
    iNsim = 1000
    i_MC_list = np.arange(1, iNsim+1)
    
    sBNames = ['LBWB']#,'MB','BW','NBW','CBW','SB', 'SWB']
    for sBName in sBNames:
        print(sBName)
        
        # Use the Parallel function to apply the process_data function to the data in parallel
        results = Parallel(n_jobs=192, backend='multiprocessing', verbose=10, batch_size=int(iNsim/192))(delayed(multi_h_MC)(i_MC, sBName) for i_MC in i_MC_list)
        # Print the results
        
        re1=Simu_Band_Cov(results,iNsim)
        filename = f'FULL_{sBName}_beyond_additional.txt'
        np.savetxt(filename, re1, delimiter='', fmt='%1.4f')
        
        re4=PW_Band_Cov(results,iNsim)
        filename = f'P_{sBName}_beyond_additional.txt'
        np.savetxt(filename, re4, delimiter='', fmt='%1.4f')
        
        re5=Emp_len(results,iNsim)
        filename = f'Len_{sBName}_beyond_additional.txt'
        np.savetxt(filename, re5, delimiter='', fmt='%1.4f')