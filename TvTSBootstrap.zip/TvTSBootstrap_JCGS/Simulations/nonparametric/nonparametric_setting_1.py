# Copyright: Yicong Lin, Mingxuan Song, Bernhard van der Sluis
#
# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

# ==================================================#
# Researchers are free to use the code.
# Please cite the following papers:
# 1. Yicong Lin, Mingxuan Song and Bernhard van der Sluis (2024). Bootstrap inference for linear time-varying coefficient models in locally stationary time series.
# 2. Marina Friedrich and Yicong Lin (2024). Sieve bootstrap inference for linear time-varying coefficient models. Journal of Econometrics.

# Purpose: Simulation for fully nonparametric model, setting 1, data size n = 200. See Appendix C.4.1.

import os
os.environ['MKL_NUM_THREADS']='1' 
os.environ['OMP_NUM_THREADS']='1'
import numpy as np
# import matplotlib.pyplot as plt
from statsmodels.tsa.ar_model import ar_select_order
from joblib import Parallel, delayed
from statsmodels.tsa.ar_model import AutoReg
import math
import warnings
warnings.filterwarnings('ignore')
# import sys

alpha = 0.05
T = 200
n = T
dSqrt2 = np.sqrt(2)
d2Sqrt2 = 2*dSqrt2

# In[]
def f_x(tau):
    return tau**2


######### X Generator #########
def generateX(A):
    mX = np.zeros(shape=(T, 1))
    mX[0,0] = 0
    vz = np.random.normal(0,1,size=700)
    vXi = generateU_ZW_inde(vz)
    for i in range(1, T):
        mX[i,0] = A * mX[i - 1, 0] + vXi[i-1]
    
    return mX

######### Simulation Data #########
def simulateData(iSim):
    global taut, taut_x
    
    v_zeta = np.random.normal(0, 1, 700)
    A = 0.5
    # v_zeta_1=np.random.normal(0,1,700)
    
    mX = generateX(A)
    vU = generateU_ZW_inde(v_zeta)
    
    vY = f_x(mX[:,0]) + vU
    
    # taut = np.linspace(np.quantile(mX[:,0],0.001), np.quantile(mX[:,0],0.999),T)
    taut_x = mX[:,0]
    taut = taut_x
    
    xbar = 0
    G = np.sort(np.concatenate((taut_x, np.linspace(np.min(taut_x)-4*xbar, np.max(taut_x) + 4*xbar, 200))))

    mZ = np.ones((T,1))
    
    return vY, mZ, G

# In[]
######### Zhou & Wu Generation #########
def a(tau):
    return 1 / 2 - (tau - 0.5) ** 2

def c(tau):
    return 1 / 4 + tau / 2

def get_H(i, v_zeta):
    taut = np.arange(1,T+1,1)/T
    value = a(taut[i])
    contain = np.zeros(500)
    for j in range(500):
        contain[j] = (value ** j) * v_zeta[i - j + 500]
    return np.sum(contain) / 4

def get_G(i, v_zeta_1):
    taut = np.arange(1,T+1,1)/T
    value = c(taut[i])
    contain = np.zeros(500)
    for j in range(500):
        contain[j] = (value ** j) * v_zeta_1[i - j + 500]
    return np.sum(contain)

def generateU_ZW_inde(v_zeta):
    vU = np.zeros(200)
    for i in range(200):
        vU[i] = get_H(i, v_zeta)
    return vU

def generateU_ZW_hetero(v_zeta, v_zeta_1):
    vU = np.zeros(200)
    for i in range(200):
        vU[i] = (4 * get_H(i, v_zeta)) * (get_G(i, v_zeta_1))
    return vU / 8
    

# In[]
######### Estimation #########
def K(u):
    return (1/np.sqrt(2*np.pi))*np.exp(-0.5*u**2)
    # return np.where(np.abs(u) <= 1, 0.75 * (1 - u ** 2), 0)


def K_ZW_Q(vTi_t, h):
    return d2Sqrt2*K(dSqrt2*vTi_t/h) - K(vTi_t/h)

# def Sn(k,tau,mX,h):
#     sum=0
#     for t in range(T):
#         sum+=(mX[t].reshape(2,1)*mX[t].reshape(1,2))*((taut[t] - tau)**k) * K( (taut[t] - tau)/h )
#
#     return sum/(n*h)
# #
# def Tn(k,tau,mX,vY,h):
#     sum=0
#     for t in range(T):
#         sum+=(mX[t])*((taut[t] - tau)**k) * K( (taut[t] - tau)/h )*vY[t]
#     return sum/(n*h)

def Sn(k, tau, mX, h, times):
    u = (times[None, :] - tau) / h
    K_u = K(u)

    return np.sum((mX[:, None, :] * mX[:, :, None]) * np.reshape(((times[None, :] - tau) ** k) * K_u,
                                                                 newshape=(len(times), 1, 1)), axis=0) / (h)

def Tn(k, tau, mX, vY, h, times):
    u = (times[None, :] - tau) / h
    K_u = K(u)

    return np.sum(
        mX[:, :, None] * np.reshape((times[None, :] - tau) ** k * K_u, newshape=(len(times), 1, 1)) * vY.reshape(T, 1,
                                                                                                                 1),
        axis=0) / (h)

def get_mS(tau, mX, h, times):
    mS = np.zeros(shape=(2, 2))
    Sn0 = Sn(0, tau, mX, h, times)
    Sn1 = Sn(1, tau, mX, h, times)
    Sn2 = Sn(2, tau, mX, h, times)
    size = Sn0.shape[0]
    mS[:size, :size] = Sn0
    mS[:size, size:] = Sn1
    mS[size:, :size] = Sn1.T
    mS[size:, size:] = Sn2
    
    # for i in range(2):
    #     for j in range(2):
    #         mS[i,j]=Sn0[i,j]
    #
    # for i in range(2):
    #     for j in range(2,4):
    #         mS[i,j]=Sn1[i,j-2]
    #         mS[j,i]=mS[i,j]
    #
    # for i in range(2,4):
    #     for j in range(2,4):
    #         mS[i,j]=Sn2[i-2,j-2]
    return mS

def get_mT(tau, mX, vY, h, times):
    mT = np.zeros(shape=(2, 1))
    Tn0 = Tn(0, tau, mX, vY, h, times)
    Tn1 = Tn(1, tau, mX, vY, h, times)
    size = Tn0.shape[0]

    mT[:size, 0] = Tn0[:, 0]
    mT[size:, 0] = Tn1[:, 0]

    return mT

def estimator(vY, mX, h, tau, times):
    betahat = np.zeros(shape=(1, len(tau)))
    for i in range(len(tau)):
        mS, mT = get_mS(tau[i], mX, h, times), get_mT(tau[i], mX, vY, h, times)
        mul = np.linalg.inv(mS) @ mT
        betahat[:, i][0] = mul[0]
        # betahat[:, i][1] = mul[1]

    return betahat

######### Bandwidth Selection #########
def bandwth_selection(vY, mX, betahat):
    vYfit = betahat[0] * mX[:, 0] + betahat[1] * mX[:, 1]
    Q_h = (((vY.reshape(1, T)) @ vY) ** (-1)) * (vYfit.reshape(T, 1) @ vY.reshape(1, T))
    sigma_hat2 = np.sum((vYfit - vY) ** 2) / n
    AIC = np.log(sigma_hat2) + (2 * (np.matrix.trace(Q_h) + 1)) / (n - np.matrix.trace(Q_h) - 2)
    # print(sigma_hat2)
    GCV = sigma_hat2 / (1 - np.matrix.trace(Q_h) / n) ** 2
    return AIC, GCV


######### Bootstrap Setup #########
def AR(zhat):
    maxp = 10 * np.log10(200)
    arm_selection = ar_select_order(zhat, ic='aic', trend='n', maxlag=int(maxp))

    if arm_selection.ar_lags is None:  ######
        armodel = AutoReg(zhat, trend='n', lags=0).fit()
        max_lag = 0  ## to avoid the nonetype error
        epsilonhat = zhat
        #epsilontilde = epsilonhat #- np.mean(epsilonhat)
    else:
        armodel = arm_selection.model.fit()
        max_lag = max(arm_selection.ar_lags)
        epsilonhat = armodel.resid
        #epsilontilde = epsilonhat #- np.mean(epsilonhat)

    return epsilonhat, max_lag, armodel
# In[]
######### Sieve Bootstrap #########
def S_BT(epsilontilde, max_lag, zhat, armodel, mX, betatilde):
    epsilonstar = np.random.choice(epsilontilde, T - max_lag + 50)
    if max_lag == 0:
        zstar = epsilonstar[50:]
        zstar_array = zstar

    # elif max_lag ==1:
    #
    #     zstar_array = np.zeros(T)
    #
    #     for j in range(T - max_lag):
    #         zstar_array[j + max_lag] = zstar_array[j + max_lag-1]*armodel.params[0] +epsilonstar[20+j]
    else:

        max_lag = np.arange(1, max_lag + 1)

        zstar_array = get_Zstar_AR(max_lag, armodel, 200, epsilonstar)

    vYstar = (mX @ betatilde + zstar_array).diagonal()

    return vYstar

######### Sieve Wild Bootstrap #########
def SW_BT(epsilontilde, max_lag, zhat, armodel, mX, betatilde):
    epsilonstar = epsilontilde * np.random.normal(0, 1, T - max_lag)
    epsilonstar = np.random.choice(epsilonstar, T - max_lag + 50)
    if max_lag == 0:
        zstar = epsilonstar[50:]
        zstar_array = zstar

    # elif max_lag ==1:
    #
    #     zstar_array = np.zeros(T)
    #
    #     for j in range(T - max_lag):
    #         zstar_array[j + max_lag] = zstar_array[j + max_lag-1]*armodel.params[0] +epsilonstar[20+j]
    else:

        max_lag = np.arange(1, max_lag + 1)

        zstar_array = get_Zstar_AR(max_lag, armodel, 200, epsilonstar)

    vYstar = (mX @ betatilde + zstar_array).diagonal()

    return vYstar

def get_Zstar_AR(max_lags, armodel, T, epsilonstar):
    # Initialize the AR process with the known initial values
    zstar = np.zeros(len(max_lags))

    # Add the AR component for each lag value and coefficient
    for i in range(len(max_lags), T):
        ar_component = 0
        for j, lag in enumerate(max_lags):
            lagged_data = zstar[i - lag]
            ar_component += armodel.params[j] * lagged_data

        ar_component += epsilonstar[i + 20 - len(max_lags)]
        # print(epsilonstar[i+20-len(max_lags)])
        zstar = np.append(zstar, ar_component)
    # print(armodel.params,max_lag,zstar)
    return zstar

######### Local Moving Block Wild Bootstrap #########
def LBW_BT(zhat, mX, betatilde, h):
    l = int(4.5 * (T*h) ** (1 / 4))

    number_blocks = T - l + 1
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        overlapping_blocks[i] = np.array(zhat[i:i + l]).reshape(l, 1)

    zstar = np.zeros(shape=(l*int(np.ceil(T/l)), 1))
    for tau in range(0, T, l):
        # local_number_blocks = l if tau in [0, T - l] else 2 * l
        local_number_blocks = np.shape(overlapping_blocks[max(tau - l, 0):tau + l])[0]
        random_choice = np.random.choice(np.arange(0, local_number_blocks), 1)
        vWild = np.repeat(np.random.normal(0, 1, 1), l)
        overlapping_blocks_star = (overlapping_blocks[max(tau - l, 0):tau + l])[random_choice]
        zstar[tau:tau + l] = overlapping_blocks_star.reshape(l, 1) * vWild.reshape(l, 1)  ## wild part

    zstar = zstar[:T]

    vYstar = (mX @ betatilde + zstar).diagonal()
    

    return vYstar

######### Moving Block Bootstrap #########
def B_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = 200 - l + 1
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        overlapping_blocks[i] = np.array(zhat[i:i + l]).reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=int(200 / l))
    overlapping_blocks_star = overlapping_blocks[random_choice]
    zstar = overlapping_blocks_star.reshape(200, 1)

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Non-overlapping Block Bootstrap #########
def NB_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = int(200/l)
    non_overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        non_overlapping_blocks[i] = np.array(zhat[(i)*10:(i+1)*10]).reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=number_blocks)
    non_overlapping_blocks_star = non_overlapping_blocks[random_choice]
    zstar = non_overlapping_blocks_star.reshape(200, 1)

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar


######### Circular Block Bootstrap #########
def CB_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = 200
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    extended_zhat = np.concatenate((zhat, zhat[:l - 1]))

    for i in range(number_blocks):
        start_idx = i % len(zhat)
        end_idx = start_idx + l

        block = extended_zhat[start_idx:end_idx]
        overlapping_blocks[i] = block.reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=int(200 / l))
    overlapping_blocks_star = overlapping_blocks[random_choice]
    zstar = overlapping_blocks_star.reshape(200, 1)

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Moving Block Wild Bootstrap #########
def BW_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = 200 - l + 1
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        overlapping_blocks[i] = np.array(zhat[i:i + l]).reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=int(200 / l))
    vWild = np.repeat(np.random.normal(0, 1, 20), 10)
    overlapping_blocks_star = overlapping_blocks[random_choice]
    zstar = overlapping_blocks_star.reshape(200, 1)*vWild.reshape(200,1)## wild part

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Circular Block Wild Bootstrap #########
def CBW_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = 200
    overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    extended_zhat = np.concatenate((zhat, zhat[:l - 1]))

    for i in range(number_blocks):
        start_idx = i % len(zhat)
        end_idx = start_idx + l

        block = extended_zhat[start_idx:end_idx]
        overlapping_blocks[i] = block.reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=int(200 / l))
    vWild = np.repeat(np.random.normal(0, 1, 20), 10)
    overlapping_blocks_star = overlapping_blocks[random_choice]
    zstar = overlapping_blocks_star.reshape(200, 1)*vWild.reshape(200,1)## wild part

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Non-overlapping Block Wild Bootstrap #########
def NBW_BT(zhat, mX, betatilde):
    l = int(1.75 * 200 ** (1 / 3))

    number_blocks = int(200/l)
    non_overlapping_blocks = np.zeros(shape=(number_blocks, l, 1))
    for i in range(number_blocks):
        non_overlapping_blocks[i] = np.array(zhat[(i)*10:(i+1)*10]).reshape(l, 1)

    random_choice = np.random.choice(np.arange(0, number_blocks), size=number_blocks)
    vWild = np.repeat(np.random.normal(0, 1, 20), 10)
    non_overlapping_blocks_star = non_overlapping_blocks[random_choice]
    zstar = non_overlapping_blocks_star.reshape(200, 1)*vWild.reshape(200,1)## wild part

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Autoregressive Bootstrap #########
def AW_BT(zhat, mX, betatilde):
    # maxp = 10 * np.log10(n)
    # arm_selection = ar_select_order(zhat, ic='aic', trend='n', maxlag=int(maxp))
    # armodel = arm_selection.model.fit()
    # epsilonhat = armodel.resid
    # epsilontilde = epsilonhat - np.mean(epsilonhat)
    gamma = 0.2
    # v_nv_star=np.random.normal(0,np.sqrt(1-gamma**2),200)
    xi_star0 = np.random.normal(0, 1, 1)

    v_xi_star = np.zeros(T)
    v_xi_star[0] = xi_star0
    for i in range(1, T):
        v_xi_star[i] = gamma * v_xi_star[i - 1] + np.random.normal(0, np.sqrt(1 - gamma ** 2))

    zstar = v_xi_star * np.array(zhat)

    vYstar = (mX @ betatilde + zstar).diagonal()

    return vYstar

######### Simutaneous Bands #########
def get_qtau(alphap, diff, tau):
    qtau = np.zeros(shape=(2, len(tau)))
    for i in range(len(tau)):
        qtau[0, i] = np.quantile(diff[:, i], alphap / 2)

        qtau[1, i] = np.quantile(diff[:, i], (1 - alphap / 2))
    return qtau
# def ABS_value(qtau,diff):
#     times=0
#     for i in range(999):
#
#         if np.sum((qtau[0]<diff[i])&(diff[i]<qtau[1])) == T:
#             times+=1
#         else:
#             times=times
#     return  np.abs( (times/999)-0.95)
def ABS_value(qtau, diff, tau):
    B = 1299
    check = np.sum((qtau[0][:, None] < diff[:, :, None]) & (diff[:, :, None] < qtau[1][:, None]), axis=1)

    return np.abs((np.sum(np.where(check == len(tau), 1, 0)) / B) - 0.95)

def min_alphap(diff, tau):
    B = 1299
    last = ABS_value(get_qtau(1 / B, diff, tau), diff, tau)
    # print(last)
    for (index, alphap) in enumerate(np.arange(2, 1299) / 1299):
        qtau = get_qtau(alphap, diff, tau)
        value = ABS_value(qtau, diff, tau)
        # print(value)
        # print(index)
        # print(alphap)
        if value <= last:
            last = value
            if index == 63:
                return 0.05
        else:
            if index == 0:
                return (index + 1) / B
            if index == 1:
                return (index) / B
            else:
                return (index + 1) / B


# In[]
######### MC #########
def MC_SB(h, vY, mX, sBName, G):
    alpha = 0.05
    T = 200
    htilde = 2 * (h ** (5 / 9))
    # taut = np.arange(1 / T, (T + 1) / T, 1 / T)
    B = 1299
    
    if sBName == 'MB':
        f = B_BT
    elif sBName == 'BW':
        f = BW_BT
    elif sBName == 'NBW':
        f = NBW_BT
    elif sBName == 'CBW':
        f = CBW_BT
    elif sBName == 'LBWB':
        f = LBW_BT

    ftilde = estimator(vY, mX, htilde, taut, taut_x)
    
    ftilde_G = estimator(vY, mX, htilde, G, taut_x)
    fhat_G = estimator(vY, mX, h, G, taut_x)

    zhat = vY - (mX @ ftilde).diagonal()
    fhat_star = np.zeros(shape=(B, 1, len(G)))

    if sBName in ['SB','SWB']:
        epsilonhat,max_lag,armodel= AR(zhat)
        epsilontilde = epsilonhat  - np.mean(epsilonhat)
    # #### For Block bootstrap
    for i in range(B):
        if sBName =='SWB':
            vYstar = SW_BT(epsilonhat, max_lag, zhat, armodel, mX, ftilde)
        elif sBName == 'SB':
            vYstar = S_BT(epsilontilde, max_lag, zhat, armodel, mX, ftilde)
        elif sBName == 'LBWB':
            vYstar = LBW_BT(zhat, mX, ftilde, h)
        else:
            vYstar = f(zhat, mX, ftilde)
        
        fhat_star[i] = estimator(vYstar, mX, h, G, taut_x)

    diff_f = np.zeros(shape=(B, len(G)))
    
    for i in range(B):
        diff_f[i] = (fhat_star[i] - ftilde_G)[0]
        
    optimal_alphap = min_alphap(diff_f, G)
    
    ######## Simul band
    LB_f = fhat_G[0] - get_qtau(optimal_alphap, diff_f, G)[1]
    UB_f = fhat_G[0] - get_qtau(optimal_alphap, diff_f, G)[0]
    
    vLin = np.arange(0,len(G),1)
    lin_G_cap = np.arange(np.percentile(vLin, 10), np.percentile(vLin, 90),1, dtype=int)
    G_cap = G[lin_G_cap]
    T_g = len(lin_G_cap)
    if np.sum((LB_f[lin_G_cap] < (f_x(G_cap))) & ((f_x(G_cap)) < UB_f[lin_G_cap])) == T_g:
        if_cover = 1
    else:
        if_cover = 0

    ######## Pointiwse band
    P_LB_f = fhat_G[0] - get_qtau(alpha, diff_f, G)[1]
    P_UB_f = fhat_G[0] - get_qtau(alpha, diff_f, G)[0]

    return LB_f, UB_f, if_cover, P_LB_f, P_UB_f

def multi_h_MC(i_MC, sBName):
    # report progress
    if i_MC%100 == 0:
        print("Iteration %i out of 1000\n"%i_MC)
    
    np.random.seed(i_MC)
    vY, mX, G = simulateData(i_MC)

    h = [0.09, 0.12, 0.15 , 0.18, 0.21, 0.24]
    # h = [200**(-1/3), 200**(-1/4), 200**(-1/5), 200**(-1/6), 200**(-1/7), 200**(-1/8)]
    S_LB_f = np.zeros(shape=(6, T+200))
    S_UB_f = np.zeros(shape=(6, T+200))
    P_LB_f = np.zeros(shape=(6, T+200))
    P_UB_f = np.zeros(shape=(6, T+200))

    
    S_if_cover = np.zeros(shape=(6, 1))
    
    for i in range(6):
        S_LB_f[i], S_UB_f[i], S_if_cover[i], P_LB_f[i], P_UB_f[i]= MC_SB(h[i], vY, mX, sBName, G)

    return S_LB_f, S_UB_f, S_if_cover, P_LB_f, P_UB_f, G
    
    


def subset_U(h, i):
    vUu = np.zeros(math.floor(200 * h))
    for j in range(math.floor(200 * h)):
        vUu[j] = i / 5 - h + j / 100
    return vUu

def G_sample(h):
    G = np.concatenate((subset_U(h, 1), subset_U(h, 2), subset_U(h, 3), subset_U(h, 4)))
    G_sub = np.concatenate((subset_U(h, 1), subset_U(h, 4)))

    G, G_sub = np.unique(G.round(4)), np.unique(G_sub.round(4))
    G = G[(G*T >=0) & (G*T < 200)]
    G_sub = G_sub[(G_sub*T >=0) & (G_sub*T < 200)]
    
    len_G, len_Gsub = len(G), len(G_sub)
    
    return G, G_sub, len_G, len_Gsub

def Simu_Band_Cov(results, times):
    a = []
    c = []
    e = []
    aa = []
    cc = []
    ee = []


    for i in range(times):
        a.append(results[i][2][0])
        c.append(results[i][2][1])
        e.append(results[i][2][2])
        aa.append(results[i][2][3])
        cc.append(results[i][2][4])
        ee.append(results[i][2][5])

    return (np.sum(a) / times, np.sum(c) / times,  np.sum(e) / times, np.sum(aa) / times, np.sum(cc) / times, np.sum(ee) / times)


def PW_Band_Cov(results, times):
    a = []
    c = []
    e = []
    aa = []
    cc = []
    ee = []

    for i in range(times):
        G = results[i][5]
        vLin = np.arange(0,len(G),1)
        lin_G_cap = np.arange(np.percentile(vLin, 10), np.percentile(vLin, 90),1, dtype=int)
        G_cap = G[lin_G_cap]
        T_g = len(lin_G_cap)
        
        a.append(np.sum((results[i][3][0][lin_G_cap] < (f_x(G_cap))) & ((f_x(G_cap)) < results[i][4][0][lin_G_cap])) / T_g)
        c.append(np.sum((results[i][3][1][lin_G_cap] < (f_x(G_cap))) & ((f_x(G_cap)) < results[i][4][1][lin_G_cap])) / T_g)
        e.append(np.sum((results[i][3][2][lin_G_cap] < (f_x(G_cap))) & ((f_x(G_cap)) < results[i][4][2][lin_G_cap])) / T_g)
        aa.append(np.sum((results[i][3][3][lin_G_cap] < (f_x(G_cap))) & ((f_x(G_cap)) < results[i][4][3][lin_G_cap])) / T_g)
        cc.append(np.sum((results[i][3][4][lin_G_cap] < (f_x(G_cap))) & ((f_x(G_cap)) < results[i][4][4][lin_G_cap])) / T_g)
        ee.append(np.sum((results[i][3][5][lin_G_cap] < (f_x(G_cap))) & ((f_x(G_cap)) < results[i][4][5][lin_G_cap])) / T_g)


    return (np.average(a), np.average(c),  np.average(e), np.average(aa), np.average(cc),  np.average(ee))

def Emp_len(results, times):
    FS_len_1 = np.zeros(shape=(6, times))
    PW_len_1 = np.zeros(shape=(6, times))

    for i in range(times):
        G = results[i][5]
        vLin = np.arange(0,len(G),1)
        lin_G_cap = np.arange(np.percentile(vLin, 10), np.percentile(vLin, 90),1, dtype=int)
        
        FS_len_1[0, i] = np.median(results[i][1][0][lin_G_cap] - results[i][0][0][lin_G_cap])
        PW_len_1[0, i] = np.median(results[i][4][0][lin_G_cap] - results[i][3][0][lin_G_cap])
        
        FS_len_1[1, i] = np.median(results[i][1][1][lin_G_cap] - results[i][0][1][lin_G_cap])
        PW_len_1[1, i] = np.median(results[i][4][1][lin_G_cap] - results[i][3][1][lin_G_cap])
        
        FS_len_1[2, i] = np.median(results[i][1][2][lin_G_cap] - results[i][0][2][lin_G_cap])
        PW_len_1[2, i] = np.median(results[i][4][2][lin_G_cap] - results[i][3][2][lin_G_cap])
        
        FS_len_1[3, i] = np.median(results[i][1][3][lin_G_cap] - results[i][0][3][lin_G_cap])
        PW_len_1[3, i] = np.median(results[i][4][3][lin_G_cap] - results[i][3][3][lin_G_cap])
        
        FS_len_1[4, i] = np.median(results[i][1][4][lin_G_cap] - results[i][0][4][lin_G_cap])
        PW_len_1[4, i] = np.median(results[i][4][4][lin_G_cap] - results[i][3][4][lin_G_cap])
        
        FS_len_1[5, i] = np.median(results[i][1][5][lin_G_cap] - results[i][0][5][lin_G_cap])
        PW_len_1[5, i] = np.median(results[i][4][5][lin_G_cap] - results[i][3][5][lin_G_cap])


    return (np.average(FS_len_1, axis=1), np.average(PW_len_1, axis=1))

# # Define the number of times you want to run the function
# num_iterations = 200
#
# # Use the Parallel function to run the function in parallel for a number of iterations
# results = Parallel(n_jobs=-1)(delayed(multi_h_MC)() for _ in range(num_iterations))

if __name__ == '__main__':
    iNsim = 1000
    
    i_MC_list = np.arange(1, iNsim+1)
    
    sBNames = ['LBWB']#,'NBW','CBW','SB', 'SWB']
    for sBName in sBNames:
        print(sBName)
        
        # Use the Parallel function to apply the process_data function to the data in parallel
        results = Parallel(n_jobs=192, backend='multiprocessing', verbose=10, batch_size=int(iNsim/192))(delayed(multi_h_MC)(i_MC, sBName) for i_MC in i_MC_list)
        # Print the results
        
        re1=Simu_Band_Cov(results,iNsim)
        filename = f'FULL_{sBName}_NLR_A05_NL1.txt'
        np.savetxt(filename, re1, delimiter='', fmt='%1.4f')
        
        re4=PW_Band_Cov(results,iNsim)
        filename = f'P_{sBName}_NLR_A05_NL1.txt'
        np.savetxt(filename, re4, delimiter='', fmt='%1.4f')
        
        re5=Emp_len(results,iNsim)
        filename = f'Len_{sBName}_NLR_A05_NL1.txt'
        np.savetxt(filename, re5, delimiter='', fmt='%1.4f')